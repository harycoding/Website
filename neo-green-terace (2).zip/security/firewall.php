<?php
// ================================
// Neo Green Terrace - Main Firewall
// 10-Layer Security Protection
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    http_response_code(403);
    exit('Access Denied');
}

// Load required files
require_once __DIR__ . '/session-manager.php';
require_once __DIR__ . '/rate-limiter.php';
require_once __DIR__ . '/input-validator.php';

// ================================
// 1. IP FILTERING & GEOLOCATION
// ================================
function checkIPSecurity() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    
    // Check if IP is in blacklist
    $blacklistedIPs = [
        // Add malicious IPs here
    ];
    
    if (in_array($ip, $blacklistedIPs)) {
        logSecurityEvent('blocked_ip', $ip, 'Blacklisted IP attempted access', 'critical');
        blockAccess('Your IP has been blocked');
    }
    
    // Check for suspicious IP patterns
    if (preg_match('/^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)/', $ip)) {
        // Private IP ranges - could be proxy
        logSecurityEvent('suspicious_ip', $ip, 'Private IP range detected', 'medium');
    }
    
    return true;
}

// ================================
// 2. USER AGENT & BOT DETECTION
// ================================
function checkUserAgent() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Empty user agent is suspicious
    if (empty($userAgent)) {
        logSecurityEvent('empty_ua', $_SERVER['REMOTE_ADDR'], 'Empty user agent', 'high');
        blockAccess('Invalid request');
    }
    
    // Bot patterns
    $botPatterns = [
        '/bot/i', '/crawl/i', '/spider/i', '/scraper/i', '/curl/i', 
        '/wget/i', '/python/i', '/java/i', '/perl/i', '/ruby/i'
    ];
    
    foreach ($botPatterns as $pattern) {
        if (preg_match($pattern, $userAgent)) {
            // Allow good bots
            $goodBots = ['/googlebot/i', '/bingbot/i', '/slurp/i', '/duckduckbot/i'];
            $isGoodBot = false;
            
            foreach ($goodBots as $goodBot) {
                if (preg_match($goodBot, $userAgent)) {
                    $isGoodBot = true;
                    break;
                }
            }
            
            if (!$isGoodBot) {
                logSecurityEvent('bad_bot', $_SERVER['REMOTE_ADDR'], "Bad bot detected: $userAgent", 'medium');
                blockAccess('Bot access not allowed');
            }
        }
    }
    
    return true;
}

// ================================
// 3. RATE LIMITING
// ================================
function checkRateLimit() {
    $limiter = new RateLimiter();
    
    // Different limits for different resources
    $limits = [
        'general' => ['requests' => 60, 'window' => 60],      // 60 requests per minute
        'api' => ['requests' => 30, 'window' => 60],          // 30 API calls per minute
        'upload' => ['requests' => 10, 'window' => 300],      // 10 uploads per 5 minutes
        'login' => ['requests' => 5, 'window' => 300]         // 5 login attempts per 5 minutes
    ];
    
    $resource = determineResourceType();
    $limit = $limits[$resource] ?? $limits['general'];
    
    if (!$limiter->checkLimit($_SERVER['REMOTE_ADDR'], $resource, $limit['requests'], $limit['window'])) {
        logSecurityEvent('rate_limit', $_SERVER['REMOTE_ADDR'], "Rate limit exceeded for $resource", 'high');
        http_response_code(429);
        exit('Too many requests. Please try again later.');
    }
    
    return true;
}

// ================================
// 4. HTTP HEADER VALIDATION
// ================================
function validateHeaders() {
    // Required headers
    $requiredHeaders = ['HTTP_HOST', 'HTTP_USER_AGENT'];
    
    foreach ($requiredHeaders as $header) {
        if (empty($_SERVER[$header])) {
            logSecurityEvent('missing_header', $_SERVER['REMOTE_ADDR'], "Missing required header: $header", 'high');
            blockAccess('Invalid request headers');
        }
    }
    
    // Validate Host header to prevent host header injection
    $allowedHosts = [$_SERVER['SERVER_NAME'], 'localhost', '127.0.0.1'];
    $host = $_SERVER['HTTP_HOST'];
    
    if (!in_array($host, $allowedHosts)) {
        logSecurityEvent('invalid_host', $_SERVER['REMOTE_ADDR'], "Invalid host header: $host", 'critical');
        blockAccess('Invalid host');
    }
    
    return true;
}

// ================================
// 5. REFERER VALIDATION
// ================================
function validateReferer() {
    // Skip referer check for direct access to main pages
    if (in_array($_SERVER['REQUEST_URI'], ['/', '/index.php'])) {
        return true;
    }
    
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    
    // For POST requests, referer should be from same domain
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($referer)) {
        $refererHost = parse_url($referer, PHP_URL_HOST);
        $currentHost = $_SERVER['HTTP_HOST'];
        
        if ($refererHost !== $currentHost) {
            logSecurityEvent('csrf_attempt', $_SERVER['REMOTE_ADDR'], "Cross-site request from: $referer", 'critical');
            blockAccess('Invalid request origin');
        }
    }
    
    return true;
}

// ================================
// 6. REQUEST SIZE & CONTENT VALIDATION
// ================================
function validateRequestSize() {
    // Check Content-Length
    $contentLength = $_SERVER['CONTENT_LENGTH'] ?? 0;
    $maxSize = 10 * 1024 * 1024; // 10MB default
    
    if ($contentLength > $maxSize) {
        logSecurityEvent('oversized_request', $_SERVER['REMOTE_ADDR'], "Request too large: $contentLength bytes", 'high');
        http_response_code(413);
        exit('Request entity too large');
    }
    
    // Validate Content-Type for POST requests
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        $allowedTypes = [
            'application/x-www-form-urlencoded',
            'multipart/form-data',
            'application/json',
            'text/plain'
        ];
        
        $isValidType = false;
        foreach ($allowedTypes as $type) {
            if (strpos($contentType, $type) !== false) {
                $isValidType = true;
                break;
            }
        }
        
        if (!$isValidType && !empty($contentType)) {
            logSecurityEvent('invalid_content_type', $_SERVER['REMOTE_ADDR'], "Invalid content type: $contentType", 'medium');
            blockAccess('Invalid content type');
        }
    }
    
    return true;
}

// ================================
// 7. SQL INJECTION PROTECTION
// ================================
function checkSQLInjection() {
    $validator = new InputValidator();
    
    // Check all input sources
    $sources = [$_GET, $_POST, $_COOKIE];
    
    foreach ($sources as $source) {
        foreach ($source as $key => $value) {
            if ($validator->hasSQLInjectionPattern($value)) {
                logSecurityEvent('sql_injection', $_SERVER['REMOTE_ADDR'], "SQL injection attempt in $key", 'critical');
                blockAccess('Invalid input detected');
            }
        }
    }
    
    return true;
}

// ================================
// 8. XSS PROTECTION
// ================================
function checkXSS() {
    $validator = new InputValidator();
    
    // Check GET and POST for XSS patterns
    $sources = [$_GET, $_POST];
    
    foreach ($sources as $source) {
        foreach ($source as $key => $value) {
            if ($validator->hasXSSPattern($value)) {
                logSecurityEvent('xss_attempt', $_SERVER['REMOTE_ADDR'], "XSS attempt in $key", 'critical');
                blockAccess('Invalid input detected');
            }
        }
    }
    
    return true;
}

// ================================
// 9. FILE UPLOAD VALIDATION
// ================================
function validateFileUploads() {
    if (empty($_FILES)) {
        return true;
    }
    
    foreach ($_FILES as $file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        // Check file size
        if ($file['size'] > MAX_FILE_SIZE) {
            logSecurityEvent('oversized_upload', $_SERVER['REMOTE_ADDR'], "File too large: {$file['name']}", 'medium');
            blockAccess('File too large');
        }
        
        // Check file extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = array_merge(ALLOWED_IMAGE_TYPES, ALLOWED_VIDEO_TYPES, ALLOWED_DOC_TYPES);
        
        if (!in_array($extension, $allowedExtensions)) {
            logSecurityEvent('invalid_file_type', $_SERVER['REMOTE_ADDR'], "Invalid file type: $extension", 'high');
            blockAccess('Invalid file type');
        }
        
        // Check MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        $allowedMimes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'video/mp4', 'video/webm', 'video/ogg',
            'application/pdf', 'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        
        if (!in_array($mimeType, $allowedMimes)) {
            logSecurityEvent('invalid_mime_type', $_SERVER['REMOTE_ADDR'], "Invalid MIME type: $mimeType", 'high');
            blockAccess('Invalid file format');
        }
    }
    
    return true;
}

// ================================
// 10. ANOMALY DETECTION
// ================================
function detectAnomalies() {
    // Check for suspicious patterns in request
    $requestUri = $_SERVER['REQUEST_URI'] ?? '';
    
    // Common attack patterns
    $suspiciousPatterns = [
        '/\.\./i',              // Directory traversal
        '/etc\/passwd/i',       // System file access
        '/wp-admin/i',          // WordPress attacks
        '/phpmyadmin/i',        // Database access attempts
        '/\.env/i',             // Environment file access
        '/\.git/i',             // Git folder access
        '/backup\./i',          // Backup file access
        '/\.sql/i',             // SQL file access
        '/shell\./i',           // Shell access
        '/cmd=/i',              // Command injection
        '/exec\(/i',            // Code execution
        '/system\(/i',          // System calls
        '/eval\(/i'             // Eval attempts
    ];
    
    foreach ($suspiciousPatterns as $pattern) {
        if (preg_match($pattern, $requestUri)) {
            logSecurityEvent('suspicious_request', $_SERVER['REMOTE_ADDR'], "Suspicious pattern in URI: $requestUri", 'critical');
            blockAccess('Access denied');
        }
    }
    
    // Check for long URLs (possible buffer overflow attempts)
    if (strlen($requestUri) > 2048) {
        logSecurityEvent('long_url', $_SERVER['REMOTE_ADDR'], "Extremely long URL: " . strlen($requestUri) . " chars", 'high');
        blockAccess('Request too long');
    }
    
    return true;
}

// ================================
// HELPER FUNCTIONS
// ================================

function determineResourceType() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    
    if (strpos($uri, '/api/') !== false) {
        return 'api';
    } elseif (strpos($uri, '/upload') !== false) {
        return 'upload';
    } elseif (strpos($uri, '/login') !== false || strpos($uri, '/admin') !== false) {
        return 'login';
    }
    
    return 'general';
}

function logSecurityEvent($type, $ip, $description, $severity = 'low') {
    global $pdo;
    
    // Log to database
    try {
        $stmt = $pdo->prepare("
            INSERT INTO security_logs (event_type, severity, ip_address, user_agent, description, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $type,
            $severity,
            $ip,
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            $description
        ]);
    } catch (Exception $e) {
        // Fallback to file logging
        error_log("Security Event: [$severity] $type - $ip - $description");
    }
    
    // Also log to file
    $logEntry = date('[Y-m-d H:i:s]') . " [$severity] [$type] IP: $ip - $description" . PHP_EOL;
    file_put_contents(LOG_PATH . 'security.log', $logEntry, FILE_APPEND | LOCK_EX);
}

function blockAccess($message = 'Access Denied') {
    http_response_code(403);
    
    // Clean message for output
    $message = htmlspecialchars($message);
    
    die("
    <!DOCTYPE html>
    <html>
    <head>
        <title>403 Forbidden</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: #f5f5f5;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .error-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                text-align: center;
                max-width: 500px;
            }
            h1 { color: #e74c3c; }
            p { color: #555; }
        </style>
    </head>
    <body>
        <div class='error-container'>
            <h1>403 Forbidden</h1>
            <p>$message</p>
        </div>
    </body>
    </html>
    ");
}

// ================================
// MAIN FIREWALL EXECUTION
// ================================
function runFirewall() {
    // Execute all security checks
    checkIPSecurity();
    checkUserAgent();
    checkRateLimit();
    validateHeaders();
    validateReferer();
    validateRequestSize();
    checkSQLInjection();
    checkXSS();
    validateFileUploads();
    detectAnomalies();
    
    // If all checks pass, continue
    return true;
}

// Auto-execute firewall
runFirewall();