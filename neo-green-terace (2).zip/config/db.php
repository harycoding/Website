<?php
// ================================
// Neo Green Terrace - Database Connection
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    http_response_code(403);
    exit('Access Denied');
}

try {
    // Create PDO instance
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci"
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    // Set timezone for MySQL
    $pdo->exec("SET time_zone = '+07:00'");
    
} catch (PDOException $e) {
    // Log error details
    log_error('Database Connection Error: ' . $e->getMessage());
    
    // Show user-friendly error in production
    if (ENVIRONMENT === 'production') {
        http_response_code(500);
        die('
            <!DOCTYPE html>
            <html>
            <head>
                <title>Database Error - Neo Green Terrace</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background: #f5f5f5;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .error-container {
                        background: white;
                        padding: 40px;
                        border-radius: 10px;
                        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                        text-align: center;
                        max-width: 500px;
                    }
                    h1 { color: #e74c3c; margin-bottom: 20px; }
                    p { color: #555; line-height: 1.6; }
                    .back-link {
                        display: inline-block;
                        margin-top: 20px;
                        padding: 10px 20px;
                        background: #3498db;
                        color: white;
                        text-decoration: none;
                        border-radius: 5px;
                    }
                </style>
            </head>
            <body>
                <div class="error-container">
                    <h1>Oops! Terjadi Kesalahan</h1>
                    <p>Maaf, kami sedang mengalami masalah teknis. Tim kami sudah diberitahu dan sedang memperbaiki masalah ini.</p>
                    <p>Silakan coba lagi dalam beberapa saat.</p>
                    <a href="/" class="back-link">Kembali ke Beranda</a>
                </div>
            </body>
            </html>
        ');
    } else {
        // Show detailed error in development
        die('<h2>Database Connection Failed</h2><pre>' . $e->getMessage() . '</pre>');
    }
}

// ================================
// Database Helper Functions
// ================================

/**
 * Execute query with error handling
 */
function db_query($sql, $params = []) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        log_error('Database Query Error: ' . $e->getMessage() . ' | SQL: ' . $sql);
        return false;
    }
}

/**
 * Get single row
 */
function db_get_row($sql, $params = []) {
    $stmt = db_query($sql, $params);
    return $stmt ? $stmt->fetch() : null;
}

/**
 * Get all rows
 */
function db_get_all($sql, $params = []) {
    $stmt = db_query($sql, $params);
    return $stmt ? $stmt->fetchAll() : [];
}

/**
 * Get single value
 */
function db_get_value($sql, $params = []) {
    $stmt = db_query($sql, $params);
    return $stmt ? $stmt->fetchColumn() : null;
}

/**
 * Insert data
 */
function db_insert($table, $data) {
    global $pdo;
    
    $fields = array_keys($data);
    $values = array_map(function($field) { return ':' . $field; }, $fields);
    
    $sql = "INSERT INTO `$table` (`" . implode('`, `', $fields) . "`) VALUES (" . implode(', ', $values) . ")";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($data);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        log_error('Database Insert Error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Update data
 */
function db_update($table, $data, $where, $whereParams = []) {
    global $pdo;
    
    $setParts = [];
    foreach ($data as $field => $value) {
        $setParts[] = "`$field` = :$field";
    }
    
    $sql = "UPDATE `$table` SET " . implode(', ', $setParts) . " WHERE $where";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($data, $whereParams));
        return $stmt->rowCount();
    } catch (PDOException $e) {
        log_error('Database Update Error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Delete data
 */
function db_delete($table, $where, $params = []) {
    global $pdo;
    
    $sql = "DELETE FROM `$table` WHERE $where";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        log_error('Database Delete Error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Check if record exists
 */
function db_exists($table, $where, $params = []) {
    $sql = "SELECT COUNT(*) FROM `$table` WHERE $where";
    return (int)db_get_value($sql, $params) > 0;
}

/**
 * Begin transaction
 */
function db_begin() {
    global $pdo;
    return $pdo->beginTransaction();
}

/**
 * Commit transaction
 */
function db_commit() {
    global $pdo;
    return $pdo->commit();
}

/**
 * Rollback transaction
 */
function db_rollback() {
    global $pdo;
    return $pdo->rollBack();
}

/**
 * Escape string for LIKE queries
 */
function db_escape_like($string) {
    return str_replace(['%', '_'], ['\%', '\_'], $string);
}