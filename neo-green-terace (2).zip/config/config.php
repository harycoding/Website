<?php
// ================================
// Neo Green Terrace - Configuration
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    http_response_code(403);
    exit('Access Denied');
}

// ================================
// Environment Configuration
// ================================
define('ENVIRONMENT', 'production'); // development, production

// Error reporting based on environment
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
}

// ================================
// Base URL Configuration
// ================================
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domainName = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$scriptPath = ($scriptPath === '/') ? '' : $scriptPath;

define('BASE_URL', $protocol . $domainName . $scriptPath . '/');
define('SITE_NAME', 'Neo Green Terrace');
define('COMPANY_NAME', 'PT Rekana Dalan Terpercaya');

// ================================
// Path Configuration
// ================================
define('ROOT_PATH', str_replace('\\', '/', realpath(__DIR__ . '/../')) . '/');
define('CONFIG_PATH', ROOT_PATH . 'config/');
define('PUBLIC_PATH', ROOT_PATH . 'public/');
define('ADMIN_PATH', ROOT_PATH . 'admin/');
define('SECURITY_PATH', ROOT_PATH . 'security/');
define('UPLOAD_PATH', ROOT_PATH . 'uploads/');
define('LOG_PATH', ROOT_PATH . 'logs/');
define('BACKUP_PATH', ROOT_PATH . 'backup/');
define('TEMP_PATH', ROOT_PATH . 'temp/');

// ================================
// Upload Configuration
// ================================
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50 MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_VIDEO_TYPES', ['mp4', 'webm', 'ogg']);
define('ALLOWED_DOC_TYPES', ['pdf', 'doc', 'docx']);

// Upload subfolders
$uploadFolders = [
    'hero', 'logo', 'banner', 'product-icons', 'unit-types', 
    'gallery', 'video-short', 'facilities', 'map', 
    'testimonials', 'barcode'
];

// ================================
// Security Configuration
// ================================
define('SESSION_LIFETIME', 1800); // 30 minutes
define('SESSION_NAME', 'NGT_SESSION');
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SECRET_KEY', hash('sha256', SITE_NAME . $domainName . '2025#NGT'));

// ================================
// Database Configuration
// ================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'neogreen_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ================================
// Contact Information
// ================================
define('CONTACT_EMAIL', 'ptrekanadalanterpercaya@gmail.com');
define('CONTACT_PHONE', '082123862050');
define('CONTACT_WHATSAPP', '6282123862050');

// Social Media
define('SOCIAL_INSTAGRAM', 'becausesheneeds');
define('SOCIAL_FACEBOOK', 'TejoPrayitno');
define('SOCIAL_TIKTOK', 'jojo.propertingt25');

// ================================
// Timezone & Locale
// ================================
date_default_timezone_set('Asia/Jakarta');
setlocale(LC_ALL, 'id_ID.UTF-8', 'id_ID', 'Indonesian');

// ================================
// Session Configuration
// ================================
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.name', SESSION_NAME);
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);

// ================================
// Security Headers
// ================================
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(self), microphone=(), camera=()');

if (ENVIRONMENT === 'production' && isset($_SERVER['HTTPS'])) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

// ================================
// Create Required Directories
// ================================
$requiredDirs = [
    UPLOAD_PATH,
    LOG_PATH,
    BACKUP_PATH,
    TEMP_PATH
];

foreach ($requiredDirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        
        // Add .htaccess protection
        $htaccess = "Options -Indexes\n";
        $htaccess .= "Order allow,deny\n";
        $htaccess .= "Deny from all\n";
        
        if ($dir === UPLOAD_PATH) {
            $htaccess = "Options -Indexes\n";
            $htaccess .= "<FilesMatch \"\.(jpg|jpeg|png|gif|webp|mp4|webm|pdf)$\">\n";
            $htaccess .= "    Order allow,deny\n";
            $htaccess .= "    Allow from all\n";
            $htaccess .= "</FilesMatch>\n";
            $htaccess .= "<FilesMatch \"\.(php|php3|php4|php5|phtml|pl|py|jsp|asp|sh|cgi)$\">\n";
            $htaccess .= "    Order allow,deny\n";
            $htaccess .= "    Deny from all\n";
            $htaccess .= "</FilesMatch>";
        }
        
        file_put_contents($dir . '.htaccess', $htaccess);
    }
}

// Create upload subfolders
foreach ($uploadFolders as $folder) {
    $path = UPLOAD_PATH . $folder . '/';
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
    }
}

// ================================
// Helper Functions
// ================================

/**
 * Get asset URL
 */
function asset_url($path = '') {
    return BASE_URL . ltrim($path, '/');
}

/**
 * Get upload URL
 */
function upload_url($path = '') {
    return BASE_URL . 'uploads/' . ltrim($path, '/');
}

/**
 * Get admin URL
 */
function admin_url($path = '') {
    return BASE_URL . 'admin/' . ltrim($path, '/');
}

/**
 * Redirect helper
 */
function redirect($url, $permanent = false) {
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}

/**
 * Is HTTPS
 */
function is_https() {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
}

/**
 * Generate CSRF token
 */
function generate_csrf_token() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Verify CSRF token
 */
function verify_csrf_token($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Sanitize output
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Log error
 */
function log_error($message, $file = 'error.log') {
    $timestamp = date('[Y-m-d H:i:s]');
    $log_message = $timestamp . ' ' . $message . PHP_EOL;
    error_log($log_message, 3, LOG_PATH . $file);
}

/**
 * Log activity
 */
function log_activity($type, $message, $user = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (type, message, user, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $type,
            $message,
            $user,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        log_error('Activity log error: ' . $e->getMessage());
    }
}