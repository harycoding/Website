<?php
// ================================
// Neo Green Terrace - Gallery Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get gallery items from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, filename, category 
        FROM gallery 
        WHERE is_active = 1 
        ORDER BY position ASC, id DESC
    ");
    $stmt->execute();
    $galleryItems = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Gallery section error: ' . $e->getMessage());
    $galleryItems = [];
}

// Default gallery items if none in database
if (empty($galleryItems)) {
    $galleryItems = [
        ['title' => 'Tampak Depan', 'filename' => 'gallery-1.jpg', 'category' => 'exterior'],
        ['title' => 'Ruang Tamu', 'filename' => 'gallery-2.jpg', 'category' => 'interior'],
        ['title' => 'Kamar Tidur', 'filename' => 'gallery-3.jpg', 'category' => 'interior'],
        ['title' => 'Taman', 'filename' => 'gallery-4.jpg', 'category' => 'facility'],
        ['title' => 'Area Parkir', 'filename' => 'gallery-5.jpg', 'category' => 'facility']
    ];
}

// Get unique categories
$categories = array_unique(array_column($galleryItems, 'category'));
array_unshift($categories, 'all'); // Add 'all' as first option

// Language translations
$translations = [
    'id' => [
        'title' => 'Galeri Foto',
        'subtitle' => 'Lihat berbagai sudut dan fasilitas Neo Green Terrace',
        'all' => 'Semua',
        'exterior' => 'Eksterior',
        'interior' => 'Interior',
        'facility' => 'Fasilitas',
        'view_larger' => 'Lihat lebih besar'
    ],
    'en' => [
        'title' => 'Photo Gallery',
        'subtitle' => 'Explore various angles and facilities of Neo Green Terrace',
        'all' => 'All',
        'exterior' => 'Exterior',
        'interior' => 'Interior',
        'facility' => 'Facilities',
        'view_larger' => 'View larger'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];
?>

<section id="gallery" class="gallery-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <!-- Category Filter -->
        <?php if (count($categories) > 1): ?>
        <div class="gallery-filter" data-aos="fade-up" data-aos-delay="100">
            <?php foreach ($categories as $category): ?>
                <button 
                    class="filter-btn <?= $category === 'all' ? 'active' : '' ?>" 
                    data-filter="<?= e($category) ?>">
                    <?= e($t[$category] ?? ucfirst($category)) ?>
                </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Gallery Grid with Horizontal Scroll -->
        <div class="gallery-wrapper">
            <div class="gallery-scroll" id="gallery-scroll">
                <?php foreach ($galleryItems as $index => $item): 
                    $imgPath = upload_url('gallery/' . $item['filename']);
                    $defaultImg = asset_url('public/assets/images/gallery-default.jpg');
                    $category = $item['category'] ?? 'uncategorized';
                ?>
                    <div class="gallery-item" 
                         data-category="<?= e($category) ?>"
                         data-aos="fade-up" 
                         data-aos-delay="<?= min($index * 50, 300) ?>">
                        <div class="gallery-img-wrapper">
                            <img 
                                src="<?= $imgPath ?>" 
                                alt="<?= e($item['title']) ?>"
                                loading="lazy"
                                data-full="<?= $imgPath ?>"
                                onerror="this.onerror=null; this.src='<?= $defaultImg ?>'">
                            
                            <div class="gallery-overlay">
                                <button class="gallery-zoom" data-index="<?= $index ?>" aria-label="<?= e($t['view_larger']) ?>">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <path d="m21 21-4.35-4.35"></path>
                                        <line x1="11" y1="8" x2="11" y2="14"></line>
                                        <line x1="8" y1="11" x2="14" y2="11"></line>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        
                        <?php if (!empty($item['title'])): ?>
                        <p><?= e($item['title']) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Scroll Indicators -->
            <button class="gallery-scroll-btn gallery-scroll-left" aria-label="Scroll left">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <button class="gallery-scroll-btn gallery-scroll-right" aria-label="Scroll right">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
        </div>
    </div>
</section>

<!-- Lightbox Modal -->
<div id="gallery-lightbox" class="gallery-lightbox" style="display: none;">
    <button class="lightbox-close" aria-label="Close">&times;</button>
    <button class="lightbox-prev" aria-label="Previous">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
    </button>
    <button class="lightbox-next" aria-label="Next">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
    </button>
    <div class="lightbox-content">
        <img id="lightbox-image" src="" alt="">
        <div class="lightbox-caption">
            <p id="lightbox-title"></p>
            <span id="lightbox-counter"></span>
        </div>
    </div>
</div>

<style>
/* Gallery Additional Styles */
.gallery-filter {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 0.5rem 1.5rem;
    background: var(--bg-secondary);
    border: 2px solid transparent;
    border-radius: var(--radius-full);
    font-weight: 500;
    cursor: pointer;
    transition: all var(--transition-fast);
}

.filter-btn:hover {
    border-color: var(--primary-color);
}

.filter-btn.active {
    background: var(--primary-color);
    color: white;
}

.gallery-wrapper {
    position: relative;
}

.gallery-img-wrapper {
    position: relative;
    overflow: hidden;
    border-radius: var(--radius-lg);
    height: 200px;
}

.gallery-img-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-slow);
}

.gallery-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity var(--transition-normal);
}

.gallery-item:hover .gallery-overlay {
    opacity: 1;
}

.gallery-item:hover .gallery-img-wrapper img {
    transform: scale(1.1);
}

.gallery-zoom {
    background: white;
    border: none;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: transform var(--transition-fast);
}

.gallery-zoom:hover {
    transform: scale(1.1);
}

/* Scroll Buttons */
.gallery-scroll-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(255, 255, 255, 0.9);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: var(--shadow-md);
    transition: all var(--transition-fast);
    z-index: 10;
}

.gallery-scroll-btn:hover {
    background: white;
    box-shadow: var(--shadow-lg);
}

.gallery-scroll-left {
    left: -20px;
}

.gallery-scroll-right {
    right: -20px;
}

/* Hide scroll buttons when not needed */
.gallery-scroll-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

/* Lightbox */
.gallery-lightbox {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.95);
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn 0.3s ease;
}

.lightbox-content {
    max-width: 90%;
    max-height: 90%;
    position: relative;
}

.lightbox-content img {
    max-width: 100%;
    max-height: 80vh;
    object-fit: contain;
}

.lightbox-close {
    position: absolute;
    top: 20px;
    right: 20px;
    background: none;
    border: none;
    color: white;
    font-size: 3rem;
    cursor: pointer;
    z-index: 2001;
}

.lightbox-prev,
.lightbox-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(255, 255, 255, 0.1);
    border: none;
    color: white;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background var(--transition-fast);
}

.lightbox-prev:hover,
.lightbox-next:hover {
    background: rgba(255, 255, 255, 0.2);
}

.lightbox-prev {
    left: 20px;
}

.lightbox-next {
    right: 20px;
}

.lightbox-caption {
    text-align: center;
    color: white;
    margin-top: 1rem;
}

.lightbox-caption p {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: white;
}

.lightbox-counter {
    font-size: 0.9rem;
    opacity: 0.8;
}

/* Filtering animation */
.gallery-item {
    transition: all 0.3s ease;
}

.gallery-item.hidden {
    opacity: 0;
    transform: scale(0.8);
    position: absolute;
    pointer-events: none;
}

/* Dark mode adjustments */
body.dark-theme .gallery-scroll-btn {
    background: rgba(45, 45, 45, 0.9);
    color: white;
}

body.dark-theme .gallery-zoom {
    background: var(--bg-secondary);
    color: white;
}

/* Mobile adjustments */
@media (max-width: 768px) {
    .gallery-scroll-btn {
        display: none;
    }
    
    .lightbox-prev,
    .lightbox-next {
        width: 40px;
        height: 40px;
    }
}
</style>

<script>
// Gallery functionality
document.addEventListener('DOMContentLoaded', function() {
    const galleryScroll = document.getElementById('gallery-scroll');
    const scrollLeftBtn = document.querySelector('.gallery-scroll-left');
    const scrollRightBtn = document.querySelector('.gallery-scroll-right');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.getElementById('gallery-lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const lightboxTitle = document.getElementById('lightbox-title');
    const lightboxCounter = document.getElementById('lightbox-counter');
    
    let currentImageIndex = 0;
    let visibleImages = [];
    
    // Horizontal scroll functionality
    if (galleryScroll && scrollLeftBtn && scrollRightBtn) {
        const scrollAmount = 320; // Width of one item plus gap
        
        function updateScrollButtons() {
            scrollLeftBtn.disabled = galleryScroll.scrollLeft <= 0;
            scrollRightBtn.disabled = galleryScroll.scrollLeft >= galleryScroll.scrollWidth - galleryScroll.clientWidth;
        }
        
        scrollLeftBtn.addEventListener('click', () => {
            galleryScroll.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });
        
        scrollRightBtn.addEventListener('click', () => {
            galleryScroll.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });
        
        galleryScroll.addEventListener('scroll', updateScrollButtons);
        updateScrollButtons();
        
        // Mouse wheel horizontal scroll
        galleryScroll.addEventListener('wheel', (e) => {
            if (e.deltaY !== 0) {
                e.preventDefault();
                galleryScroll.scrollLeft += e.deltaY;
            }
        });
    }
    
    // Filter functionality
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.dataset.filter;
            
            // Update active button
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Filter items
            galleryItems.forEach(item => {
                if (filter === 'all' || item.dataset.category === filter) {
                    item.classList.remove('hidden');
                } else {
                    item.classList.add('hidden');
                }
            });
            
            // Track filter usage
            if (typeof trackClick === 'function') {
                trackClick(`Gallery Filter: ${filter}`, 'GALLERY_FILTER');
            }
        });
    });
    
    // Lightbox functionality
    function updateVisibleImages() {
        visibleImages = Array.from(galleryItems)
            .filter(item => !item.classList.contains('hidden'))
            .map(item => ({
                src: item.querySelector('img').dataset.full || item.querySelector('img').src,
                title: item.querySelector('p')?.textContent || ''
            }));
    }
    
    function openLightbox(index) {
        updateVisibleImages();
        currentImageIndex = index;
        showImage(currentImageIndex);
        lightbox.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
        // Track lightbox open
        if (typeof trackClick === 'function') {
            trackClick('Gallery Lightbox Open', 'GALLERY_LIGHTBOX');
        }
    }
    
    function showImage(index) {
        if (visibleImages.length === 0) return;
        
        const image = visibleImages[index];
        lightboxImage.src = image.src;
        lightboxImage.alt = image.title;
        lightboxTitle.textContent = image.title;
        lightboxCounter.textContent = `${index + 1} / ${visibleImages.length}`;
    }
    
    // Zoom button click
    document.querySelectorAll('.gallery-zoom').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const index = parseInt(this.dataset.index);
            openLightbox(index);
        });
    });
    
    // Lightbox navigation
    document.querySelector('.lightbox-close')?.addEventListener('click', () => {
        lightbox.style.display = 'none';
        document.body.style.overflow = '';
    });
    
    document.querySelector('.lightbox-prev')?.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex - 1 + visibleImages.length) % visibleImages.length;
        showImage(currentImageIndex);
    });
    
    document.querySelector('.lightbox-next')?.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex + 1) % visibleImages.length;
        showImage(currentImageIndex);
    });
    
    // Close lightbox on background click
    lightbox?.addEventListener('click', function(e) {
        if (e.target === this || e.target === lightboxImage.parentElement) {
            this.style.display = 'none';
            document.body.style.overflow = '';
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (lightbox.style.display === 'flex') {
            if (e.key === 'Escape') {
                lightbox.style.display = 'none';
                document.body.style.overflow = '';
            } else if (e.key === 'ArrowLeft') {
                document.querySelector('.lightbox-prev').click();
            } else if (e.key === 'ArrowRight') {
                document.querySelector('.lightbox-next').click();
            }
        }
    });
    
    // Track gallery item clicks
    galleryItems.forEach((item, index) => {
        item.addEventListener('click', function() {
            const title = this.querySelector('p')?.textContent || `Gallery Item ${index + 1}`;
            if (typeof trackClick === 'function') {
                trackClick(`Gallery View: ${title}`, 'GALLERY_VIEW');
            }
        });
    });
    
    // Initialize
    updateVisibleImages();
});
</script>