/* ===================================================
   Neo Green Terrace - VISITOR TRACKER
   Version: 1.0
   File: public/assets/js/visitor-tracker.js
=================================================== */

(function() {
    'use strict';

    // Configuration
    const TRACKING_ENDPOINT = '/admin/api/track-visitor.php';
    const CLICK_ENDPOINT = '/admin/api/track-click.php';
    const VIDEO_ENDPOINT = '/admin/api/track-video.php';
    const SESSION_KEY = 'ngt_session_id';
    const TRACKING_INTERVAL = 30000; // 30 seconds

    // Generate or get session ID
    function getSessionId() {
        let sessionId = sessionStorage.getItem(SESSION_KEY);
        if (!sessionId) {
            sessionId = generateUUID();
            sessionStorage.setItem(SESSION_KEY, sessionId);
        }
        return sessionId;
    }

    // Generate UUID v4
    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    // Get browser info
    function getBrowserInfo() {
        const ua = navigator.userAgent;
        let browser = 'Unknown';
        let os = 'Unknown';
        let device = 'Desktop';

        // Detect browser
        if (ua.indexOf('Firefox') > -1) {
            browser = 'Firefox';
        } else if (ua.indexOf('Chrome') > -1 && ua.indexOf('Edg') === -1) {
            browser = 'Chrome';
        } else if (ua.indexOf('Safari') > -1 && ua.indexOf('Chrome') === -1) {
            browser = 'Safari';
        } else if (ua.indexOf('Edg') > -1) {
            browser = 'Edge';
        } else if (ua.indexOf('MSIE') > -1 || ua.indexOf('Trident/') > -1) {
            browser = 'Internet Explorer';
        }

        // Detect OS
        if (ua.indexOf('Windows NT') > -1) {
            os = 'Windows';
        } else if (ua.indexOf('Mac OS X') > -1) {
            os = 'macOS';
        } else if (ua.indexOf('Linux') > -1) {
            os = 'Linux';
        } else if (ua.indexOf('Android') > -1) {
            os = 'Android';
        } else if (ua.indexOf('iOS') > -1) {
            os = 'iOS';
        }

        // Detect device type
        if (/Mobile|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)) {
            device = 'Mobile';
        } else if (/Tablet|iPad/i.test(ua)) {
            device = 'Tablet';
        }

        return { browser, os, device };
    }

    // Get visitor data
    function getVisitorData() {
        const browserInfo = getBrowserInfo();
        
        return {
            session_id: getSessionId(),
            page_url: window.location.href,
            page_title: document.title,
            referrer: document.referrer || 'Direct',
            screen_width: window.screen.width,
            screen_height: window.screen.height,
            viewport_width: window.innerWidth,
            viewport_height: window.innerHeight,
            user_agent: navigator.userAgent,
            browser: browserInfo.browser,
            os: browserInfo.os,
            device: browserInfo.device,
            language: navigator.language || navigator.userLanguage,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            timestamp: new Date().toISOString()
        };
    }

    // Send tracking data
    function sendTrackingData(endpoint, data) {
        // Use Beacon API if available for better performance
        if (navigator.sendBeacon) {
            const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
            navigator.sendBeacon(endpoint, blob);
        } else {
            // Fallback to fetch
            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data),
                keepalive: true
            }).catch(error => {
                console.error('Tracking error:', error);
            });
        }
    }

    // Track page visit
    function trackPageVisit() {
        const data = getVisitorData();
        sendTrackingData(TRACKING_ENDPOINT, data);
    }

    // Track click events
    function trackClick(target, elementType, customData = {}) {
        const data = {
            session_id: getSessionId(),
            target: target,
            element_type: elementType,
            page: window.location.pathname,
            timestamp: new Date().toISOString(),
            ...customData
        };
        sendTrackingData(CLICK_ENDPOINT, data);
    }

    // Track video views
    function trackVideo(videoId, videoType, event, duration = 0) {
        const data = {
            session_id: getSessionId(),
            video_id: videoId,
            video_type: videoType,
            event: event, // 'play', 'pause', 'end', 'progress'
            duration: duration,
            timestamp: new Date().toISOString()
        };
        sendTrackingData(VIDEO_ENDPOINT, data);
    }

    // Expose tracking functions globally
    window.trackClick = trackClick;
    window.trackVideo = trackVideo;

    // Track time on page
    let startTime = Date.now();
    let isActive = true;
    let lastActiveTime = Date.now();

    function updateTimeOnPage() {
        if (isActive) {
            const currentTime = Date.now();
            const timeOnPage = Math.round((currentTime - startTime) / 1000);
            
            const data = {
                session_id: getSessionId(),
                page: window.location.pathname,
                time_on_page: timeOnPage,
                is_active: isActive
            };
            
            sendTrackingData(TRACKING_ENDPOINT, data);
        }
    }

    // Detect user activity
    function resetActiveTimer() {
        isActive = true;
        lastActiveTime = Date.now();
    }

    // Check if user is idle
    function checkIdleState() {
        const currentTime = Date.now();
        const idleTime = currentTime - lastActiveTime;
        
        // Consider user idle after 5 minutes of inactivity
        if (idleTime > 300000) {
            isActive = false;
        }
    }

    // Activity listeners
    ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
        document.addEventListener(event, resetActiveTimer, { passive: true });
    });

    // Page visibility API
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            isActive = false;
        } else {
            resetActiveTimer();
        }
    });

    // Track specific interactions
    function initializeInteractionTracking() {
        // Track CTA button clicks
        document.querySelectorAll('.hero-btn, .btn-detail, .wa-float').forEach(button => {
            button.addEventListener('click', function() {
                const label = this.textContent || this.getAttribute('aria-label') || 'Unknown';
                trackClick(label, 'CTA_BUTTON', {
                    button_class: this.className,
                    button_href: this.href || ''
                });
            });
        });

        // Track navigation clicks
        document.querySelectorAll('.navbar-menu a').forEach(link => {
            link.addEventListener('click', function() {
                trackClick(this.textContent, 'NAVIGATION', {
                    nav_href: this.href
                });
            });
        });

        // Track gallery interactions
        document.querySelectorAll('.gallery-item').forEach((item, index) => {
            item.addEventListener('click', function() {
                trackClick(`Gallery Item ${index + 1}`, 'GALLERY', {
                    image_src: this.querySelector('img')?.src || ''
                });
            });
        });

        // Track video interactions
        document.querySelectorAll('video').forEach((video, index) => {
            const videoId = video.id || `video-${index}`;
            const videoType = video.classList.contains('hero-video') ? 'hero' : 'short';

            video.addEventListener('play', () => {
                trackVideo(videoId, videoType, 'play');
            });

            video.addEventListener('pause', () => {
                trackVideo(videoId, videoType, 'pause', video.currentTime);
            });

            video.addEventListener('ended', () => {
                trackVideo(videoId, videoType, 'end', video.duration);
            });

            // Track progress every 10 seconds
            let lastProgress = 0;
            video.addEventListener('timeupdate', () => {
                const currentProgress = Math.floor(video.currentTime / 10);
                if (currentProgress > lastProgress) {
                    lastProgress = currentProgress;
                    trackVideo(videoId, videoType, 'progress', video.currentTime);
                }
            });
        });

        // Track form submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const formId = this.id || 'unknown-form';
                trackClick(formId, 'FORM_SUBMIT', {
                    form_action: this.action,
                    form_method: this.method
                });
            });
        });
    }

    // Track scroll depth
    let maxScrollDepth = 0;
    function trackScrollDepth() {
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = window.pageYOffset;
        const scrollDepth = Math.round((scrolled / scrollHeight) * 100);
        
        if (scrollDepth > maxScrollDepth) {
            maxScrollDepth = scrollDepth;
            
            // Track at 25%, 50%, 75%, and 100%
            if ([25, 50, 75, 100].includes(maxScrollDepth)) {
                trackClick(`Scroll Depth ${maxScrollDepth}%`, 'SCROLL', {
                    depth: maxScrollDepth
                });
            }
        }
    }

    // Throttle scroll tracking
    let scrollTimer;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimer);
        scrollTimer = setTimeout(trackScrollDepth, 100);
    });

    // Track page unload
    window.addEventListener('beforeunload', () => {
        const timeOnPage = Math.round((Date.now() - startTime) / 1000);
        
        const data = {
            session_id: getSessionId(),
            page: window.location.pathname,
            event: 'page_unload',
            time_on_page: timeOnPage,
            max_scroll_depth: maxScrollDepth
        };
        
        // Use sendBeacon for reliable delivery
        if (navigator.sendBeacon) {
            const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
            navigator.sendBeacon(TRACKING_ENDPOINT, blob);
        }
    });

    // Initialize tracking
    function init() {
        // Track initial page visit
        trackPageVisit();
        
        // Initialize interaction tracking
        initializeInteractionTracking();
        
        // Set up periodic time tracking
        setInterval(updateTimeOnPage, TRACKING_INTERVAL);
        
        // Set up idle check
        setInterval(checkIdleState, 60000); // Check every minute
        
        console.log('Visitor tracking initialized');
    }

    // Start tracking when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();