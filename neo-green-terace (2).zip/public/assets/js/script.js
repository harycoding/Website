/* ===================================================
   Neo Green Terrace - PUBLIC JAVASCRIPT
   Version: 1.0
   File: public/assets/js/script.js
=================================================== */

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // =========== LOADING SCREEN ===========
    const loadingScreen = document.querySelector('.loading-screen');
    if (loadingScreen) {
        window.addEventListener('load', () => {
            setTimeout(() => {
                loadingScreen.classList.add('hide');
            }, 500);
        });
    }

    // =========== NAVBAR FUNCTIONALITY ===========
    const navbar = document.querySelector('.navbar');
    const navbarMenu = document.querySelector('.navbar-menu');
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarLinks = document.querySelectorAll('.navbar-menu a');

    // Navbar scroll effect
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Hide/show navbar on scroll
        if (currentScroll > lastScroll && currentScroll > 300) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }

        lastScroll = currentScroll;
    });

    // Mobile menu toggle
    if (navbarToggle) {
        navbarToggle.addEventListener('click', () => {
            navbarMenu.classList.toggle('active');
            navbarToggle.classList.toggle('active');
            
            // Animate hamburger
            const spans = navbarToggle.querySelectorAll('span');
            if (navbarToggle.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
            } else {
                spans.forEach(span => {
                    span.style.transform = '';
                    span.style.opacity = '';
                });
            }
        });
    }

    // Close mobile menu on link click
    navbarLinks.forEach(link => {
        link.addEventListener('click', () => {
            navbarMenu.classList.remove('active');
            navbarToggle.classList.remove('active');
        });
    });

    // =========== SMOOTH SCROLLING ===========
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offset = navbar.offsetHeight;
                const targetPosition = target.offsetTop - offset;
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // =========== THEME TOGGLE ===========
    const themeToggle = document.querySelector('.theme-toggle');
    const body = document.body;
    const currentTheme = localStorage.getItem('theme') || 'light';

    // Apply saved theme
    if (currentTheme === 'dark') {
        body.classList.add('dark-theme');
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            const theme = body.classList.contains('dark-theme') ? 'dark' : 'light';
            localStorage.setItem('theme', theme);
            
            // Update theme icon
            const icon = themeToggle.querySelector('svg');
            if (theme === 'dark') {
                icon.innerHTML = '<path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>';
            } else {
                icon.innerHTML = '<path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>';
            }
        });
    }

    // =========== BACK TO TOP BUTTON ===========
    const backToTop = document.getElementById('back-to-top');
    if (backToTop) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTop.classList.add('show');
            } else {
                backToTop.classList.remove('show');
            }
        });

        backToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // =========== BANNER CAROUSEL ===========
    const bannerWrapper = document.querySelector('.banner-wrapper');
    const bannerSlides = document.querySelectorAll('.banner-slide');
    
    if (bannerWrapper && bannerSlides.length > 1) {
        let currentSlide = 0;
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % bannerSlides.length;
            bannerWrapper.style.transform = `translateX(-${currentSlide * 100}%)`;
        }
        
        // Auto slide every 4 seconds
        setInterval(nextSlide, 4000);
        
        // Touch/swipe support
        let touchStartX = 0;
        let touchEndX = 0;
        
        bannerWrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        });
        
        bannerWrapper.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });
        
        function handleSwipe() {
            if (touchEndX < touchStartX - 50) {
                nextSlide();
            }
            if (touchEndX > touchStartX + 50) {
                currentSlide = currentSlide === 0 ? bannerSlides.length - 1 : currentSlide - 1;
                bannerWrapper.style.transform = `translateX(-${currentSlide * 100}%)`;
            }
        }
    }

    // =========== INTERSECTION OBSERVER FOR ANIMATIONS ===========
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('appear');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe all fade-in elements
    document.querySelectorAll('.fade-in').forEach(el => {
        observer.observe(el);
    });

    // Add fade-in class to elements
    const elementsToAnimate = [
        '.section-title',
        '.feature-box',
        '.unit-box',
        '.gallery-item',
        '.short-video-card',
        '.facility-card',
        '.testimonial-item'
    ];

    elementsToAnimate.forEach(selector => {
        document.querySelectorAll(selector).forEach(el => {
            el.classList.add('fade-in');
            observer.observe(el);
        });
    });

    // =========== VIDEO CONTROLS ===========
    const heroVideo = document.querySelector('.hero-video');
    if (heroVideo) {
        // Ensure video plays
        heroVideo.play().catch(e => {
            console.log('Auto-play was prevented');
        });
        
        // Pause video when not in viewport
        const videoObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    heroVideo.play();
                } else {
                    heroVideo.pause();
                }
            });
        }, { threshold: 0.5 });
        
        videoObserver.observe(heroVideo);
    }

    // =========== LAZY LOADING FOR GALLERY ===========
    const galleryImages = document.querySelectorAll('.gallery-item img, .short-video-card video');
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
                imageObserver.unobserve(img);
            }
        });
    }, { rootMargin: '50px' });

    galleryImages.forEach(img => {
        imageObserver.observe(img);
    });

    // =========== HORIZONTAL SCROLL WITH MOUSE WHEEL ===========
    const horizontalScrollContainers = [
        '.gallery-scroll',
        '.short-video-scroll',
        '.testimonial-carousel'
    ];

    horizontalScrollContainers.forEach(selector => {
        const container = document.querySelector(selector);
        if (container) {
            container.addEventListener('wheel', (e) => {
                if (e.deltaY !== 0) {
                    e.preventDefault();
                    container.scrollLeft += e.deltaY;
                }
            });
        }
    });

    // =========== FORM PROTECTION ===========
    // Disable right-click
    document.addEventListener('contextmenu', (e) => {
        if (e.target.tagName === 'IMG' || e.target.tagName === 'VIDEO') {
            e.preventDefault();
            return false;
        }
    });

    // Disable drag for images
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('dragstart', (e) => {
            e.preventDefault();
            return false;
        });
    });

    // =========== KEYBOARD SHORTCUTS ===========
    document.addEventListener('keydown', (e) => {
        // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
        if (e.keyCode === 123 || 
            (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) ||
            (e.ctrlKey && e.keyCode === 85)) {
            e.preventDefault();
            return false;
        }
    });

    // =========== PERFORMANCE OPTIMIZATION ===========
    // Debounce function
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Throttle function
    function throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    // Apply throttle to scroll events
    const throttledScroll = throttle(() => {
        // Handle scroll events
    }, 100);

    window.addEventListener('scroll', throttledScroll);

    // =========== CLICK TRACKING ===========
    // Track button clicks for analytics
    document.querySelectorAll('a, button').forEach(element => {
        element.addEventListener('click', function() {
            const target = this.href || this.innerText || 'Unknown';
            const elementType = this.tagName;
            
            // Send to visitor tracker
            if (typeof trackClick === 'function') {
                trackClick(target, elementType);
            }
        });
    });

    // =========== ACCESSIBILITY ===========
    // Skip link functionality
    const skipLink = document.querySelector('.skip-link');
    if (skipLink) {
        skipLink.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(skipLink.getAttribute('href'));
            if (target) {
                target.tabIndex = -1;
                target.focus();
            }
        });
    }

    // =========== ERROR HANDLING ===========
    window.addEventListener('error', (e) => {
        console.error('Script error:', e.message);
        // Log errors for debugging
        if (typeof logError === 'function') {
            logError(e.message, e.filename, e.lineno, e.colno);
        }
    });

    // =========== INIT COMPLETE ===========
    console.log('Neo Green Terrace website initialized successfully');
});