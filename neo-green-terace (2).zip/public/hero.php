<?php
// ================================
// Neo Green Terrace - Hero Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get hero data from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, subtitle, video_path, video_thumbnail, cta_text, cta_link 
        FROM hero_section 
        WHERE is_active = 1 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->execute();
    $hero = $stmt->fetch();
    
    // Default values if no data
    if (!$hero) {
        $hero = [
            'video_path' => 'hero/default-hero.mp4',
            'video_thumbnail' => 'hero/default-poster.jpg',
            'title' => null,
            'subtitle' => null,
            'cta_text' => null,
            'cta_link' => null
        ];
    }
} catch (PDOException $e) {
    log_error('Hero section error: ' . $e->getMessage());
    $hero = [
        'video_path' => 'hero/default-hero.mp4',
        'video_thumbnail' => 'hero/default-poster.jpg',
        'title' => null,
        'subtitle' => null,
        'cta_text' => null,
        'cta_link' => null
    ];
}

// Full paths
$videoPath = upload_url($hero['video_path']);
$posterPath = upload_url($hero['video_thumbnail']);

// Check if files exist, use defaults if not
if (!file_exists(UPLOAD_PATH . $hero['video_path'])) {
    $videoPath = asset_url('public/assets/videos/default-hero.mp4');
}
if (!file_exists(UPLOAD_PATH . $hero['video_thumbnail'])) {
    $posterPath = asset_url('public/assets/images/hero-poster.jpg');
}
?>

<section id="hero" class="hero-section">
    <div class="hero-video-wrapper">
        <!-- Background Video -->
        <video 
            class="hero-video" 
            autoplay 
            muted 
            loop 
            playsinline 
            poster="<?= e($posterPath) ?>"
            oncontextmenu="return false;"
            disablePictureInPicture
            controlsList="nodownload">
            <source src="<?= e($videoPath) ?>" type="video/mp4">
            <source src="<?= e(str_replace('.mp4', '.webm', $videoPath)) ?>" type="video/webm">
            <!-- Fallback image for browsers that don't support video -->
            <img src="<?= e($posterPath) ?>" alt="Neo Green Terrace">
        </video>
        
        <!-- Dark overlay -->
        <div class="hero-overlay"></div>
        
        <!-- Content Overlay (only show if title/subtitle exists) -->
        <?php if ($hero['title'] || $hero['subtitle'] || $hero['cta_text']): ?>
        <div class="hero-content fade-in">
            <?php if ($hero['title']): ?>
                <h1><?= e($hero['title']) ?></h1>
            <?php endif; ?>
            
            <?php if ($hero['subtitle']): ?>
                <p><?= e($hero['subtitle']) ?></p>
            <?php endif; ?>
            
            <?php if ($hero['cta_text'] && $hero['cta_link']): ?>
                <a href="<?= e($hero['cta_link']) ?>" class="hero-btn">
                    <?= e($hero['cta_text']) ?>
                </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <!-- Scroll indicator -->
        <div class="scroll-indicator">
            <div class="mouse">
                <div class="wheel"></div>
            </div>
            <div class="arrows">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
</section>

<style>
/* Hero Section Styles */
.scroll-indicator {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 3;
    animation: bounce 2s infinite;
}

.mouse {
    width: 26px;
    height: 40px;
    border: 2px solid rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    position: relative;
    margin: 0 auto;
}

.wheel {
    width: 4px;
    height: 8px;
    background: rgba(255, 255, 255, 0.8);
    border-radius: 2px;
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    animation: scroll 2s infinite;
}

.arrows {
    margin-top: 10px;
}

.arrows span {
    display: block;
    width: 10px;
    height: 10px;
    border-right: 2px solid rgba(255, 255, 255, 0.8);
    border-bottom: 2px solid rgba(255, 255, 255, 0.8);
    transform: rotate(45deg);
    margin: -5px auto;
    animation: arrow 2s infinite;
}

.arrows span:nth-child(2) {
    animation-delay: -0.3s;
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translateX(-50%) translateY(0);
    }
    40% {
        transform: translateX(-50%) translateY(-10px);
    }
    60% {
        transform: translateX(-50%) translateY(-5px);
    }
}

@keyframes scroll {
    0% {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    100% {
        opacity: 0;
        transform: translateX(-50%) translateY(10px);
    }
}

@keyframes arrow {
    0% {
        opacity: 0;
    }
    50% {
        opacity: 1;
    }
    100% {
        opacity: 0;
    }
}

/* Ensure video doesn't have controls on mobile */
.hero-video::-webkit-media-controls {
    display: none !important;
}

.hero-video::-webkit-media-controls-enclosure {
    display: none !important;
}
</style>

<script>
// Hero video optimization
document.addEventListener('DOMContentLoaded', function() {
    const heroVideo = document.querySelector('.hero-video');
    
    if (heroVideo) {
        // Ensure video plays on mobile
        heroVideo.play().catch(function(error) {
            console.log('Auto-play prevented:', error);
            // Try playing on user interaction
            document.addEventListener('click', function playVideo() {
                heroVideo.play();
                document.removeEventListener('click', playVideo);
            }, { once: true });
        });
        
        // Pause video when out of viewport for performance
        const videoObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    heroVideo.play();
                } else {
                    heroVideo.pause();
                }
            });
        }, { threshold: 0.25 });
        
        videoObserver.observe(heroVideo);
        
        // Track video views
        let tracked = false;
        heroVideo.addEventListener('play', function() {
            if (!tracked && typeof trackVideo === 'function') {
                trackVideo('hero-video', 'hero', 'play');
                tracked = true;
            }
        });
    }
    
    // Smooth scroll on indicator click
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        scrollIndicator.addEventListener('click', function() {
            const nextSection = document.querySelector('#banner-section') || document.querySelector('.section');
            if (nextSection) {
                nextSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
});
</script>