<?php
// ================================
// Neo Green Terrace - Banner Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get banner data from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, filename, link_url, alt_text 
        FROM banners 
        WHERE is_active = 1 
        ORDER BY position ASC, id DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $banners = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Banner section error: ' . $e->getMessage());
    $banners = [];
}

// Only show section if there are banners
if (empty($banners)) {
    return;
}
?>

<section id="banner-section" class="banner-section">
    <div class="container">
        <div class="banner-carousel">
            <div class="banner-wrapper" id="banner-wrapper">
                <?php foreach ($banners as $index => $banner): 
                    $imgPath = upload_url('banner/' . $banner['filename']);
                    $altText = e($banner['alt_text'] ?: 'Banner ' . ($index + 1));
                    $hasLink = !empty($banner['link_url']);
                ?>
                    <div class="banner-slide" data-slide="<?= $index ?>">
                        <?php if ($hasLink): ?>
                            <a href="<?= e($banner['link_url']) ?>" target="_blank" rel="noopener">
                        <?php endif; ?>
                        
                        <img 
                            src="<?= $imgPath ?>" 
                            alt="<?= $altText ?>"
                            loading="<?= $index === 0 ? 'eager' : 'lazy' ?>"
                            class="banner-image"
                            onerror="this.onerror=null; this.src='<?= asset_url('public/assets/images/default-banner.jpg') ?>'">
                        
                        <?php if ($hasLink): ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($banner['title'])): ?>
                            <div class="banner-caption">
                                <h3><?= e($banner['title']) ?></h3>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Navigation dots -->
            <?php if (count($banners) > 1): ?>
            <div class="banner-dots">
                <?php for ($i = 0; $i < count($banners); $i++): ?>
                    <button 
                        class="dot <?= $i === 0 ? 'active' : '' ?>" 
                        data-slide="<?= $i ?>"
                        aria-label="Go to slide <?= $i + 1 ?>">
                    </button>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
            
            <!-- Navigation arrows -->
            <?php if (count($banners) > 1): ?>
            <button class="banner-nav banner-prev" aria-label="Previous slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <button class="banner-nav banner-next" aria-label="Next slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
            <?php endif; ?>
        </div>
    </div>
</section>

<style>
/* Banner Section Additional Styles */
.banner-carousel {
    position: relative;
    max-width: 1200px;
    margin: 0 auto;
}

.banner-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.banner-caption {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
    color: white;
    padding: 2rem;
    transform: translateY(100%);
    transition: transform 0.3s ease;
}

.banner-slide:hover .banner-caption {
    transform: translateY(0);
}

.banner-caption h3 {
    margin: 0;
    font-size: 1.5rem;
    color: white;
}

.banner-dots {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 8px;
    z-index: 5;
}

.banner-dots .dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid white;
    background: transparent;
    cursor: pointer;
    transition: all 0.3s ease;
    padding: 0;
}

.banner-dots .dot.active {
    background: white;
    width: 24px;
    border-radius: 5px;
}

.banner-nav {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0, 0, 0, 0.5);
    color: white;
    border: none;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    z-index: 5;
}

.banner-nav:hover {
    background: rgba(0, 0, 0, 0.8);
}

.banner-prev {
    left: 20px;
}

.banner-next {
    right: 20px;
}

/* Mobile adjustments */
@media (max-width: 768px) {
    .banner-nav {
        width: 40px;
        height: 40px;
    }
    
    .banner-prev {
        left: 10px;
    }
    
    .banner-next {
        right: 10px;
    }
    
    .banner-caption {
        padding: 1rem;
    }
    
    .banner-caption h3 {
        font-size: 1.2rem;
    }
}
</style>

<script>
// Banner carousel functionality
document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.getElementById('banner-wrapper');
    const slides = wrapper ? wrapper.querySelectorAll('.banner-slide') : [];
    const dots = document.querySelectorAll('.banner-dots .dot');
    const prevBtn = document.querySelector('.banner-prev');
    const nextBtn = document.querySelector('.banner-next');
    
    if (slides.length <= 1) return;
    
    let currentSlide = 0;
    let autoplayInterval;
    let isTransitioning = false;
    
    // Update slide position
    function goToSlide(index) {
        if (isTransitioning) return;
        isTransitioning = true;
        
        currentSlide = index;
        wrapper.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // Update dots
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentSlide);
        });
        
        // Track banner view
        if (typeof trackClick === 'function') {
            trackClick(`Banner ${currentSlide + 1}`, 'BANNER_VIEW');
        }
        
        setTimeout(() => {
            isTransitioning = false;
        }, 500);
    }
    
    // Next slide
    function nextSlide() {
        const next = (currentSlide + 1) % slides.length;
        goToSlide(next);
    }
    
    // Previous slide
    function prevSlide() {
        const prev = currentSlide === 0 ? slides.length - 1 : currentSlide - 1;
        goToSlide(prev);
    }
    
    // Auto play
    function startAutoplay() {
        stopAutoplay();
        autoplayInterval = setInterval(nextSlide, 4000);
    }
    
    function stopAutoplay() {
        if (autoplayInterval) {
            clearInterval(autoplayInterval);
        }
    }
    
    // Event listeners
    if (nextBtn) nextBtn.addEventListener('click', () => {
        nextSlide();
        startAutoplay();
    });
    
    if (prevBtn) prevBtn.addEventListener('click', () => {
        prevSlide();
        startAutoplay();
    });
    
    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            goToSlide(index);
            startAutoplay();
        });
    });
    
    // Touch/swipe support
    let touchStartX = 0;
    let touchEndX = 0;
    
    wrapper.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoplay();
    }, { passive: true });
    
    wrapper.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
        startAutoplay();
    }, { passive: true });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    }
    
    // Pause on hover
    wrapper.addEventListener('mouseenter', stopAutoplay);
    wrapper.addEventListener('mouseleave', startAutoplay);
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            startAutoplay();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            startAutoplay();
        }
    });
    
    // Visibility change
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            stopAutoplay();
        } else {
            startAutoplay();
        }
    });
    
    // Start autoplay
    startAutoplay();
    
    // Track banner clicks
    slides.forEach((slide, index) => {
        const link = slide.querySelector('a');
        if (link) {
            link.addEventListener('click', () => {
                if (typeof trackClick === 'function') {
                    trackClick(`Banner ${index + 1} Click`, 'BANNER_CLICK', {
                        banner_url: link.href
                    });
                }
            });
        }
    });
});
</script>