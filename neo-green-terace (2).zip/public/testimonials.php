<?php
// ================================
// Neo Green Terrace - Testimonials Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get testimonials from database
try {
    $stmt = $pdo->prepare("
        SELECT name, occupation, message, photo, rating 
        FROM testimonials 
        WHERE is_active = 1 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $testimonials = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Testimonials section error: ' . $e->getMessage());
    $testimonials = [];
}

// Default testimonials if none in database
if (empty($testimonials)) {
    $testimonials = [
        [
            'name' => 'Budi Santoso',
            'occupation' => 'Pengusaha',
            'message' => 'Sangat puas dengan Neo Green Terrace. Lokasi strategis, fasilitas lengkap, dan lingkungan yang asri membuat keluarga saya betah tinggal di sini.',
            'photo' => 'testimonial-1.jpg',
            'rating' => 5
        ],
        [
            'name' => 'Sarah Wijaya',
            'occupation' => 'Dokter',
            'message' => 'Investasi terbaik yang pernah saya lakukan. Harga terjangkau dengan kualitas bangunan yang sangat baik. Developer sangat profesional.',
            'photo' => 'testimonial-2.jpg',
            'rating' => 5
        ],
        [
            'name' => 'Ahmad Fadli',
            'occupation' => 'PNS',
            'message' => 'Proses pembelian mudah dan transparan. Tim marketing sangat membantu. Sekarang kami memiliki rumah impian di lokasi yang sempurna.',
            'photo' => 'testimonial-3.jpg',
            'rating' => 5
        ]
    ];
}

// Language translations
$translations = [
    'id' => [
        'title' => 'Apa Kata Mereka?',
        'subtitle' => 'Testimoni dari penghuni yang telah merasakan kenyamanan tinggal di Neo Green Terrace',
        'read_more' => 'Baca lebih lanjut',
        'all_testimonials' => 'Lihat Semua Testimoni'
    ],
    'en' => [
        'title' => 'What They Say?',
        'subtitle' => 'Testimonials from residents who have experienced the comfort of living in Neo Green Terrace',
        'read_more' => 'Read more',
        'all_testimonials' => 'View All Testimonials'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];
?>

<section id="testimonials" class="testimonial-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="testimonial-wrapper">
            <div class="testimonial-carousel" id="testimonial-carousel">
                <?php foreach ($testimonials as $index => $testimonial): 
                    $photoPath = upload_url('testimonials/' . $testimonial['photo']);
                    $defaultPhoto = asset_url('public/assets/images/user-default.jpg');
                ?>
                    <div class="testimonial-item" data-aos="fade-up" data-aos-delay="<?= min($index * 100, 300) ?>">
                        <div class="testimonial-card">
                            <!-- Quote Icon -->
                            <div class="quote-icon">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"/>
                                </svg>
                            </div>
                            
                            <!-- Rating Stars -->
                            <?php if (!empty($testimonial['rating'])): ?>
                            <div class="testimonial-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="<?= $i <= $testimonial['rating'] ? '#FFD700' : '#E0E0E0' ?>">
                                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                    </svg>
                                <?php endfor; ?>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Message -->
                            <div class="testimonial-message">
                                <p>"<?= e($testimonial['message']) ?>"</p>
                            </div>
                            
                            <!-- Author Info -->
                            <div class="testimonial-author">
                                <div class="author-photo">
                                    <img 
                                        src="<?= $photoPath ?>" 
                                        alt="<?= e($testimonial['name']) ?>"
                                        loading="lazy"
                                        onerror="this.onerror=null; this.src='<?= $defaultPhoto ?>'">
                                </div>
                                <div class="author-info">
                                    <h4 class="testimonial-name"><?= e($testimonial['name']) ?></h4>
                                    <?php if (!empty($testimonial['occupation'])): ?>
                                    <span class="testimonial-occupation"><?= e($testimonial['occupation']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Navigation -->
            <div class="testimonial-nav">
                <button class="nav-btn nav-prev" aria-label="Previous testimonial">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </button>
                <div class="nav-dots">
                    <?php foreach ($testimonials as $index => $item): ?>
                        <button class="nav-dot <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>" aria-label="Go to testimonial <?= $index + 1 ?>"></button>
                    <?php endforeach; ?>
                </div>
                <button class="nav-btn nav-next" aria-label="Next testimonial">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- CTA Section -->
        <div class="testimonial-cta" data-aos="fade-up" data-aos-delay="400">
            <h3>Bergabunglah dengan Keluarga Besar Neo Green Terrace</h3>
            <p>Jadilah bagian dari komunitas yang harmonis dan berkembang</p>
            <div class="cta-buttons">
                <a href="#unit-types" class="btn-primary">
                    Lihat Unit Tersedia
                </a>
                <button class="btn-secondary" onclick="showTestimonialForm()">
                    Bagikan Pengalaman Anda
                </button>
            </div>
        </div>
    </div>
</section>

<!-- Testimonial Form Modal -->
<div id="testimonial-modal" class="testimonial-modal" style="display: none;">
    <div class="modal-content">
        <button class="modal-close" onclick="closeTestimonialForm()">&times;</button>
        <h3>Bagikan Pengalaman Anda</h3>
        <form id="testimonial-form" onsubmit="submitTestimonial(event)">
            <div class="form-group">
                <label for="testi-name">Nama Lengkap</label>
                <input type="text" id="testi-name" name="name" required>
            </div>
            <div class="form-group">
                <label for="testi-occupation">Pekerjaan</label>
                <input type="text" id="testi-occupation" name="occupation">
            </div>
            <div class="form-group">
                <label for="testi-message">Testimoni Anda</label>
                <textarea id="testi-message" name="message" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label>Rating</label>
                <div class="rating-input">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                        <label for="star<?= $i ?>">★</label>
                    <?php endfor; ?>
                </div>
            </div>
            <button type="submit" class="btn-submit">Kirim Testimoni</button>
        </form>
    </div>
</div>

<style>
/* Testimonials Additional Styles */
.testimonial-wrapper {
    position: relative;
    max-width: 1200px;
    margin: 0 auto;
}

.testimonial-carousel {
    display: flex;
    gap: 2rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scroll-snap-type: x mandatory;
    padding: 1rem 0 2rem;
    -webkit-overflow-scrolling: touch;
}

.testimonial-carousel::-webkit-scrollbar {
    height: 6px;
}

.testimonial-carousel::-webkit-scrollbar-track {
    background: var(--bg-secondary);
    border-radius: var(--radius-full);
}

.testimonial-carousel::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: var(--radius-full);
}

.testimonial-item {
    flex: 0 0 auto;
    width: 350px;
    scroll-snap-align: center;
}

.testimonial-card {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-xl);
    box-shadow: var(--shadow-md);
    height: 100%;
    display: flex;
    flex-direction: column;
    position: relative;
    transition: all var(--transition-normal);
}

.testimonial-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
}

.quote-icon {
    position: absolute;
    top: 1rem;
    right: 1rem;
    color: var(--primary-color);
    opacity: 0.2;
}

.testimonial-rating {
    display: flex;
    gap: 0.25rem;
    margin-bottom: 1rem;
}

.testimonial-message {
    flex: 1;
    margin-bottom: 1.5rem;
}

.testimonial-message p {
    font-style: italic;
    line-height: 1.8;
    color: var(--text-secondary);
}

.testimonial-author {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-top: auto;
}

.author-photo {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
    border: 3px solid var(--primary-color);
}

.author-photo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.author-info h4 {
    margin: 0;
    font-size: 1.1rem;
    color: var(--text-primary);
}

.testimonial-occupation {
    font-size: 0.9rem;
    color: var(--text-secondary);
}

/* Navigation */
.testimonial-nav {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 2rem;
    margin-top: 2rem;
}

.nav-btn {
    background: white;
    border: 2px solid var(--bg-secondary);
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all var(--transition-fast);
}

.nav-btn:hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
}

.nav-dots {
    display: flex;
    gap: 0.5rem;
}

.nav-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid var(--primary-color);
    background: transparent;
    cursor: pointer;
    transition: all var(--transition-fast);
    padding: 0;
}

.nav-dot.active {
    background: var(--primary-color);
    width: 30px;
    border-radius: 5px;
}

/* CTA Section */
.testimonial-cta {
    text-align: center;
    margin-top: 4rem;
    padding: 3rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-xl);
}

.testimonial-cta h3 {
    font-size: 1.75rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.testimonial-cta p {
    font-size: 1.1rem;
    color: var(--text-secondary);
    margin-bottom: 2rem;
}

.cta-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.btn-primary,
.btn-secondary {
    padding: 0.875rem 2rem;
    border-radius: var(--radius-full);
    font-weight: 600;
    transition: all var(--transition-fast);
    cursor: pointer;
    border: none;
    text-decoration: none;
    display: inline-block;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: var(--secondary-color);
    transform: translateY(-2px);
    color: white;
}

.btn-secondary {
    background: white;
    color: var(--primary-color);
    border: 2px solid var(--primary-color);
}

.btn-secondary:hover {
    background: var(--primary-color);
    color: white;
}

/* Modal */
.testimonial-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    padding: 1rem;
}

.modal-content {
    background: white;
    border-radius: var(--radius-xl);
    max-width: 500px;
    width: 100%;
    padding: 2rem;
    position: relative;
    animation: modalIn 0.3s ease;
}

.modal-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--text-secondary);
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-primary);
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid var(--bg-secondary);
    border-radius: var(--radius-md);
    font-family: inherit;
    transition: border-color var(--transition-fast);
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary-color);
}

.rating-input {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
    gap: 0.5rem;
}

.rating-input input {
    display: none;
}

.rating-input label {
    font-size: 1.5rem;
    color: #ddd;
    cursor: pointer;
    transition: color var(--transition-fast);
}

.rating-input input:checked ~ label,
.rating-input label:hover,
.rating-input label:hover ~ label {
    color: #FFD700;
}

.btn-submit {
    width: 100%;
    padding: 1rem;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    font-weight: 600;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all var(--transition-fast);
}

.btn-submit:hover {
    background: var(--secondary-color);
}

/* Dark mode adjustments */
body.dark-theme .testimonial-card {
    background: var(--bg-secondary);
}

body.dark-theme .modal-content {
    background: var(--bg-dark);
    color: white;
}

body.dark-theme .form-group input,
body.dark-theme .form-group textarea {
    background: var(--bg-secondary);
    color: white;
    border-color: var(--bg-secondary);
}

/* Mobile adjustments */
@media (max-width: 768px) {
    .testimonial-item {
        width: 300px;
    }
    
    .testimonial-nav {
        display: none;
    }
    
    .cta-buttons {
        flex-direction: column;
    }
    
    .btn-primary,
    .btn-secondary {
        width: 100%;
    }
}
</style>

<script>
// Testimonial carousel functionality
document.addEventListener('DOMContentLoaded', function() {
    const carousel = document.getElementById('testimonial-carousel');
    const items = carousel.querySelectorAll('.testimonial-item');
    const prevBtn = document.querySelector('.nav-prev');
    const nextBtn = document.querySelector('.nav-next');
    const dots = document.querySelectorAll('.nav-dot');
    let currentIndex = 0;
    
    // Calculate scroll position
    function scrollToIndex(index) {
        const item = items[index];
        if (item) {
            const scrollLeft = item.offsetLeft - (carousel.offsetWidth - item.offsetWidth) / 2;
            carousel.scrollTo({
                left: scrollLeft,
                behavior: 'smooth'
            });
            
            // Update dots
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
            
            currentIndex = index;
        }
    }
    
    // Navigation buttons
    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', () => {
            const newIndex = currentIndex > 0 ? currentIndex - 1 : items.length - 1;
            scrollToIndex(newIndex);
        });
        
        nextBtn.addEventListener('click', () => {
            const newIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
            scrollToIndex(newIndex);
        });
    }
    
    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            scrollToIndex(index);
        });
    });
    
    // Auto-scroll
    let autoScrollInterval = setInterval(() => {
        const newIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
        scrollToIndex(newIndex);
    }, 5000);
    
    // Pause auto-scroll on hover
    carousel.addEventListener('mouseenter', () => {
        clearInterval(autoScrollInterval);
    });
    
    carousel.addEventListener('mouseleave', () => {
        autoScrollInterval = setInterval(() => {
            const newIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
            scrollToIndex(newIndex);
        }, 5000);
    });
    
    // Track testimonial views
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const index = Array.from(items).indexOf(entry.target);
                const name = entry.target.querySelector('.testimonial-name')?.textContent || 'Unknown';
                
                if (typeof trackClick === 'function') {
                    trackClick(`Testimonial View: ${name}`, 'TESTIMONIAL_VIEW', {
                        index: index
                    });
                }
            }
        });
    }, { threshold: 0.5 });
    
    items.forEach(item => {
        observer.observe(item);
    });
    
    // Mouse wheel horizontal scroll
    carousel.addEventListener('wheel', (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            carousel.scrollLeft += e.deltaY;
        }
    });
});

// Show testimonial form
function showTestimonialForm() {
    const modal = document.getElementById('testimonial-modal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    if (typeof trackClick === 'function') {
        trackClick('Testimonial Form Open', 'TESTIMONIAL_FORM');
    }
}

// Close testimonial form
function closeTestimonialForm() {
    const modal = document.getElementById('testimonial-modal');
    modal.style.display = 'none';
    document.body.style.overflow = '';
}

// Submit testimonial
function submitTestimonial(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
    
    // Track submission
    if (typeof trackClick === 'function') {
        trackClick('Testimonial Submit', 'TESTIMONIAL_SUBMIT', {
            rating: data.rating
        });
    }
    
    // In production, this would submit to the server
    alert('Terima kasih atas testimoni Anda! Tim kami akan meninjau dan menampilkannya segera.');
    
    // Reset form and close modal
    event.target.reset();
    closeTestimonialForm();
}

// Close modal on background click
document.getElementById('testimonial-modal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeTestimonialForm();
    }
});
</script>