<?php
// ================================
// Neo Green Terrace - Navigation Bar
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get current language
$lang = $_SESSION['lang'] ?? 'id';
$theme = $_SESSION['theme'] ?? 'light';

// Language translations
$translations = [
    'id' => [
        'home' => 'Beranda',
        'units' => 'Tipe Unit',
        'gallery' => 'Galeri',
        'facilities' => 'Fasilitas',
        'location' => 'Lokasi',
        'testimonials' => 'Testimoni',
        'contact' => 'Kontak'
    ],
    'en' => [
        'home' => 'Home',
        'units' => 'Unit Types',
        'gallery' => 'Gallery',
        'facilities' => 'Facilities',
        'location' => 'Location',
        'testimonials' => 'Testimonials',
        'contact' => 'Contact'
    ]
];

$t = $translations[$lang] ?? $translations['id'];
?>

<nav class="navbar" id="navbar">
    <div class="container navbar-container">
        <!-- Logo -->
        <div class="navbar-logo">
            <a href="#home">
                <img src="<?= upload_url('logo/logo.png') ?>" alt="Neo Green Terrace" onerror="this.src='<?= asset_url('public/assets/images/logo.png') ?>'">
            </a>
        </div>

        <!-- Menu -->
        <ul class="navbar-menu" id="navbar-menu">
            <li><a href="#hero"><?= $t['home'] ?></a></li>
            <li><a href="#unit-types"><?= $t['units'] ?></a></li>
            <li><a href="#gallery"><?= $t['gallery'] ?></a></li>
            <li><a href="#facilities"><?= $t['facilities'] ?></a></li>
            <li><a href="#location"><?= $t['location'] ?></a></li>
            <li><a href="#testimonials"><?= $t['testimonials'] ?></a></li>
        </ul>

        <!-- Actions -->
        <div class="navbar-actions">
            <!-- Language Switcher -->
            <div class="lang-switcher">
                <a href="?lang=id" class="<?= $lang === 'id' ? 'active' : '' ?>" title="Bahasa Indonesia">ID</a>
                <a href="?lang=en" class="<?= $lang === 'en' ? 'active' : '' ?>" title="English">EN</a>
                <a href="?lang=jp" class="<?= $lang === 'jp' ? 'active' : '' ?>" title="日本語">JP</a>
                <a href="?lang=kr" class="<?= $lang === 'kr' ? 'active' : '' ?>" title="한국어">KR</a>
                <a href="?lang=cn" class="<?= $lang === 'cn' ? 'active' : '' ?>" title="中文">CN</a>
            </div>

            <!-- Theme Toggle -->
            <button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme">
                <?php if ($theme === 'dark'): ?>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                <?php else: ?>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                    </svg>
                <?php endif; ?>
            </button>

            <!-- Admin Login -->
            <a href="<?= admin_url() ?>" class="admin-login" title="Admin Login">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                </svg>
            </a>

            <!-- Mobile Menu Toggle -->
            <button class="navbar-toggle" id="navbar-toggle" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</nav>