<?php
// ================================
// Neo Green Terrace - Map Location Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get map data from database
try {
    $stmt = $pdo->prepare("
        SELECT title, embed_code, latitude, longitude, zoom_level 
        FROM map 
        WHERE is_active = 1 
        ORDER BY updated_at DESC 
        LIMIT 1
    ");
    $stmt->execute();
    $map = $stmt->fetch();
} catch (PDOException $e) {
    log_error('Map section error: ' . $e->getMessage());
    $map = null;
}

// Default coordinates (Indramayu)
if (!$map) {
    $map = [
        'title' => 'Lokasi Neo Green Terrace',
        'embed_code' => '',
        'latitude' => -6.3273,
        'longitude' => 108.3330,
        'zoom_level' => 15
    ];
}

// Nearby locations
$nearbyLocations = [
    ['name' => 'Rumah Sakit', 'icon' => 'hospital', 'distance' => '5 menit', 'lat' => -6.3250, 'lng' => 108.3350],
    ['name' => 'Sekolah', 'icon' => 'school', 'distance' => '10 menit', 'lat' => -6.3290, 'lng' => 108.3310],
    ['name' => 'Pusat Perbelanjaan', 'icon' => 'shopping', 'distance' => '15 menit', 'lat' => -6.3260, 'lng' => 108.3370],
    ['name' => 'Stasiun', 'icon' => 'train', 'distance' => '20 menit', 'lat' => -6.3300, 'lng' => 108.3290]
];

// Language translations
$translations = [
    'id' => [
        'title' => 'Lokasi Strategis',
        'subtitle' => 'Terletak di kawasan yang berkembang dengan akses mudah ke berbagai fasilitas',
        'directions' => 'Petunjuk Arah',
        'nearby' => 'Fasilitas Terdekat',
        'contact_sales' => 'Hubungi Sales',
        'visit_location' => 'Kunjungi Lokasi'
    ],
    'en' => [
        'title' => 'Strategic Location',
        'subtitle' => 'Located in a developing area with easy access to various facilities',
        'directions' => 'Get Directions',
        'nearby' => 'Nearby Facilities',
        'contact_sales' => 'Contact Sales',
        'visit_location' => 'Visit Location'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];

// Generate Google Maps URL
$mapsUrl = "https://www.google.com/maps?q={$map['latitude']},{$map['longitude']}";
$directionsUrl = "https://www.google.com/maps/dir/?api=1&destination={$map['latitude']},{$map['longitude']}";
?>

<section id="location" class="map-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="map-container">
            <!-- Map Display -->
            <div class="map-wrapper" data-aos="fade-up" data-aos-delay="100">
                <?php if (!empty($map['embed_code'])): ?>
                    <!-- Google Maps Embed -->
                    <div class="map-embed">
                        <?= $map['embed_code'] ?>
                    </div>
                <?php else: ?>
                    <!-- Interactive Map Container -->
                    <div id="interactive-map" 
                         class="interactive-map" 
                         data-lat="<?= $map['latitude'] ?>" 
                         data-lng="<?= $map['longitude'] ?>" 
                         data-zoom="<?= $map['zoom_level'] ?>">
                        <div class="map-loading">
                            <div class="spinner"></div>
                            <p>Loading map...</p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Map Overlay Controls -->
                <div class="map-controls">
                    <button class="map-btn" onclick="toggleFullscreen()">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
                        </svg>
                    </button>
                    <a href="<?= $directionsUrl ?>" target="_blank" class="map-btn" rel="noopener">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 11l19-9-9 19-2-8-8-2z"></path>
                        </svg>
                    </a>
                </div>
            </div>
            
            <!-- Location Info -->
            <div class="location-info" data-aos="fade-left" data-aos-delay="200">
                <h3><?= e($map['title']) ?></h3>
                
                <!-- Address -->
                <div class="info-item">
                    <div class="info-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                    </div>
                    <div class="info-content">
                        <h4>Alamat</h4>
                        <p>Jl. Raya Indramayu KM 5, Indramayu, Jawa Barat 45213</p>
                    </div>
                </div>
                
                <!-- Nearby Facilities -->
                <div class="info-item">
                    <div class="info-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="info-content">
                        <h4><?= e($t['nearby']) ?></h4>
                        <ul class="nearby-list">
                            <?php foreach ($nearbyLocations as $location): ?>
                                <li>
                                    <span class="location-name"><?= e($location['name']) ?></span>
                                    <span class="location-distance"><?= e($location['distance']) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="location-actions">
                    <a href="<?= $directionsUrl ?>" target="_blank" class="btn-primary" rel="noopener">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 11l19-9-9 19-2-8-8-2z"></path>
                        </svg>
                        <?= e($t['directions']) ?>
                    </a>
                    <a href="https://wa.me/<?= CONTACT_WHATSAPP ?>?text=Halo,%20saya%20ingin%20berkunjung%20ke%20lokasi%20Neo%20Green%20Terrace" 
                       target="_blank" 
                       class="btn-secondary"
                       rel="noopener">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                        </svg>
                        <?= e($t['contact_sales']) ?>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Virtual Tour CTA -->
        <div class="virtual-tour-cta" data-aos="fade-up" data-aos-delay="300">
            <div class="tour-content">
                <div class="tour-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </div>
                <div class="tour-text">
                    <h3>Virtual Tour 360°</h3>
                    <p>Jelajahi Neo Green Terrace dari rumah Anda</p>
                </div>
                <button class="btn-tour" onclick="startVirtualTour()">
                    Mulai Tour Virtual
                </button>
            </div>
        </div>
    </div>
</section>

<style>
/* Map Section Additional Styles */
.map-container {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 2rem;
    margin-top: 3rem;
}

.map-wrapper {
    position: relative;
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-lg);
}

.map-embed iframe,
.interactive-map {
    width: 100%;
    height: 500px;
    border: none;
}

.interactive-map {
    background: #e5e5e5;
    position: relative;
}

.map-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.map-loading .spinner {
    width: 40px;
    height: 40px;
    border: 3px solid rgba(0, 0, 0, 0.1);
    border-top-color: var(--primary-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 1rem;
}

.map-controls {
    position: absolute;
    top: 1rem;
    right: 1rem;
    display: flex;
    gap: 0.5rem;
}

.map-btn {
    background: white;
    border: none;
    width: 40px;
    height: 40px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: var(--shadow-md);
    transition: all var(--transition-fast);
}

.map-btn:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

/* Location Info */
.location-info {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-xl);
    box-shadow: var(--shadow-md);
}

.location-info h3 {
    font-size: 1.5rem;
    margin-bottom: 1.5rem;
    color: var(--text-primary);
}

.info-item {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.info-icon {
    flex-shrink: 0;
    width: 48px;
    height: 48px;
    background: var(--bg-secondary);
    border-radius: var(--radius-lg);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--primary-color);
}

.info-content h4 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.info-content p {
    color: var(--text-secondary);
    line-height: 1.6;
}

.nearby-list {
    list-style: none;
    padding: 0;
}

.nearby-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--bg-secondary);
}

.nearby-list li:last-child {
    border-bottom: none;
}

.location-name {
    font-weight: 500;
    color: var(--text-primary);
}

.location-distance {
    font-size: 0.875rem;
    color: var(--primary-color);
    font-weight: 500;
}

.location-actions {
    display: flex;
    gap: 1rem;
    margin-top: 2rem;
}

.btn-primary,
.btn-secondary {
    flex: 1;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    transition: all var(--transition-fast);
    text-decoration: none;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: var(--secondary-color);
    transform: translateY(-2px);
    color: white;
}

.btn-secondary {
    background: #25d366;
    color: white;
}

.btn-secondary:hover {
    background: #128c7e;
    transform: translateY(-2px);
    color: white;
}

/* Virtual Tour CTA */
.virtual-tour-cta {
    margin-top: 4rem;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: var(--radius-xl);
    padding: 3rem;
    color: white;
    text-align: center;
}

.tour-content {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 2rem;
    flex-wrap: wrap;
}

.tour-icon {
    width: 80px;
    height: 80px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(10px);
}

.tour-text h3 {
    font-size: 1.75rem;
    margin-bottom: 0.5rem;
    color: white;
}

.tour-text p {
    font-size: 1.1rem;
    opacity: 0.9;
    color: white;
}

.btn-tour {
    background: white;
    color: var(--primary-color);
    border: none;
    padding: 1rem 2rem;
    border-radius: var(--radius-full);
    font-weight: 600;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all var(--transition-normal);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

.btn-tour:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.3);
}

/* Map Marker Animation */
@keyframes bounce {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-20px);
    }
}

.map-marker {
    animation: bounce 2s ease-in-out infinite;
}

/* Dark mode adjustments */
body.dark-theme .location-info {
    background: var(--bg-secondary);
}

body.dark-theme .info-icon {
    background: var(--bg-dark);
}

body.dark-theme .map-btn {
    background: var(--bg-secondary);
    color: white;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .map-container {
        grid-template-columns: 1fr;
    }
    
    .map-wrapper {
        height: 300px;
    }
    
    .map-embed iframe,
    .interactive-map {
        height: 300px;
    }
    
    .tour-content {
        flex-direction: column;
        text-align: center;
    }
    
    .location-actions {
        flex-direction: column;
    }
}
</style>

<script>
// Map functionality
document.addEventListener('DOMContentLoaded', function() {
    const interactiveMap = document.getElementById('interactive-map');
    
    // Initialize interactive map if no embed code
    if (interactiveMap) {
        const lat = parseFloat(interactiveMap.dataset.lat);
        const lng = parseFloat(interactiveMap.dataset.lng);
        const zoom = parseInt(interactiveMap.dataset.zoom);
        
        // Create simple map visualization
        // In production, you would integrate with Google Maps API or Leaflet
        const mapContent = `
            <div class="static-map">
                <img src="https://api.mapbox.com/styles/v1/mapbox/streets-v11/static/pin-l-building+00a86b(${lng},${lat})/${lng},${lat},${zoom},0/600x400@2x?access_token=YOUR_MAPBOX_TOKEN" 
                     alt="Map Location"
                     onerror="this.src='<?= asset_url('public/assets/images/map-placeholder.jpg') ?>'">
                <div class="map-marker" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -100%);">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="var(--primary-color)">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3" fill="white"></circle>
                    </svg>
                </div>
            </div>
        `;
        
        // Replace loading with map
        setTimeout(() => {
            interactiveMap.innerHTML = mapContent;
        }, 1000);
    }
    
    // Track map interactions
    document.querySelectorAll('.map-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.querySelector('svg').innerHTML.includes('M8 3') ? 'Fullscreen' : 'Directions';
            if (typeof trackClick === 'function') {
                trackClick(`Map ${action}`, 'MAP_ACTION');
            }
        });
    });
    
    // Track direction clicks
    document.querySelectorAll('a[href*="maps"]').forEach(link => {
        link.addEventListener('click', function() {
            if (typeof trackClick === 'function') {
                trackClick('Get Directions', 'MAP_DIRECTIONS');
            }
        });
    });
});

// Fullscreen toggle
function toggleFullscreen() {
    const mapWrapper = document.querySelector('.map-wrapper');
    
    if (!document.fullscreenElement) {
        mapWrapper.requestFullscreen().catch(err => {
            console.log('Error attempting to enable fullscreen:', err);
        });
    } else {
        document.exitFullscreen();
    }
}

// Virtual Tour
function startVirtualTour() {
    // Track virtual tour click
    if (typeof trackClick === 'function') {
        trackClick('Virtual Tour Start', 'VIRTUAL_TOUR');
    }
    
    // In production, this would open a 360° tour
    // For now, show a message
    alert('Virtual Tour akan segera hadir! Hubungi sales kami untuk mendapatkan akses preview.');
    
    // Optional: Open WhatsApp for virtual tour request
    // window.open(`https://wa.me/${CONTACT_WHATSAPP}?text=Halo,%20saya%20tertarik%20dengan%20virtual%20tour%20Neo%20Green%20Terrace`, '_blank');
}

// Add interactive markers for nearby locations
document.addEventListener('DOMContentLoaded', function() {
    const nearbyItems = document.querySelectorAll('.nearby-list li');
    
    nearbyItems.forEach((item, index) => {
        item.style.cursor = 'pointer';
        item.addEventListener('click', function() {
            const locationName = this.querySelector('.location-name').textContent;
            
            if (typeof trackClick === 'function') {
                trackClick(`Nearby Location: ${locationName}`, 'MAP_NEARBY');
            }
            
            // Highlight selected location
            nearbyItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            
            // In production, this would update the map marker
            console.log('Selected location:', locationName);
        });
    });
});
</script>