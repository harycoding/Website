<?php
// ================================
// Neo Green Terrace - Unit Types
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get unit types from database
try {
    $stmt = $pdo->prepare("
        SELECT id, name, size, price, description, image, bedrooms, bathrooms 
        FROM unit_types 
        WHERE is_active = 1 
        ORDER BY position ASC, id ASC
    ");
    $stmt->execute();
    $units = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Unit types error: ' . $e->getMessage());
    $units = [];
}

// Default units if none in database
if (empty($units)) {
    $units = [
        [
            'id' => 1,
            'name' => 'Tipe 36/72',
            'size' => '72',
            'price' => 450000000,
            'description' => '2 Kamar Tidur, 1 Kamar Mandi',
            'image' => 'type-36.jpg',
            'bedrooms' => 2,
            'bathrooms' => 1
        ],
        [
            'id' => 2,
            'name' => 'Tipe 45/90',
            'size' => '90',
            'price' => 650000000,
            'description' => '2 Kamar Tidur, 1 Kamar Mandi',
            'image' => 'type-45.jpg',
            'bedrooms' => 2,
            'bathrooms' => 1
        ],
        [
            'id' => 3,
            'name' => 'Tipe 54/105',
            'size' => '105',
            'price' => 850000000,
            'description' => '3 Kamar Tidur, 2 Kamar Mandi',
            'image' => 'type-54.jpg',
            'bedrooms' => 3,
            'bathrooms' => 2
        ]
    ];
}

// Language translations
$translations = [
    'id' => [
        'title' => 'Pilihan Tipe Unit',
        'subtitle' => 'Temukan hunian yang sesuai dengan kebutuhan keluarga Anda',
        'size' => 'Luas',
        'price_from' => 'Mulai dari',
        'bedrooms' => 'Kamar Tidur',
        'bathrooms' => 'Kamar Mandi',
        'view_detail' => 'Lihat Detail',
        'contact_sales' => 'Hubungi Sales'
    ],
    'en' => [
        'title' => 'Unit Type Options',
        'subtitle' => 'Find a home that suits your family needs',
        'size' => 'Size',
        'price_from' => 'Starting from',
        'bedrooms' => 'Bedrooms',
        'bathrooms' => 'Bathrooms',
        'view_detail' => 'View Details',
        'contact_sales' => 'Contact Sales'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];

// Format price function
function formatPrice($price, $lang = 'id') {
    if ($lang === 'id') {
        return 'Rp ' . number_format($price, 0, ',', '.');
    } else {
        return 'IDR ' . number_format($price, 0, '.', ',');
    }
}
?>

<section id="unit-types" class="unit-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="unit-grid">
            <?php foreach ($units as $index => $unit): 
                $imgPath = upload_url('unit-types/' . $unit['image']);
                $defaultImg = asset_url('public/assets/images/unit-default.jpg');
                $whatsappText = urlencode("Halo, saya tertarik dengan {$unit['name']} di Neo Green Terrace. Mohon informasi lebih lanjut.");
                $whatsappLink = "https://wa.me/" . CONTACT_WHATSAPP . "?text=" . $whatsappText;
            ?>
                <div class="unit-box" data-aos="fade-up" data-aos-delay="<?= $index * 100 ?>">
                    <div class="unit-img">
                        <img 
                            src="<?= $imgPath ?>" 
                            alt="<?= e($unit['name']) ?>"
                            loading="lazy"
                            onerror="this.onerror=null; this.src='<?= $defaultImg ?>'">
                        
                        <?php if (!empty($unit['price'])): ?>
                        <div class="unit-price">
                            <span class="price-label"><?= e($t['price_from']) ?></span>
                            <span class="price-value"><?= formatPrice($unit['price'], $lang) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="unit-info">
                        <h3><?= e($unit['name']) ?></h3>
                        
                        <div class="unit-specs">
                            <div class="spec-item">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="2" y="2" width="20" height="20" rx="2" ry="2"></rect>
                                    <line x1="7" y1="2" x2="7" y2="22"></line>
                                    <line x1="17" y1="2" x2="17" y2="22"></line>
                                    <line x1="2" y1="12" x2="22" y2="12"></line>
                                </svg>
                                <span><?= e($unit['size']) ?> m²</span>
                            </div>
                            
                            <?php if (!empty($unit['bedrooms'])): ?>
                            <div class="spec-item">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                </svg>
                                <span><?= e($unit['bedrooms']) ?> <?= e($t['bedrooms']) ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($unit['bathrooms'])): ?>
                            <div class="spec-item">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M5 12h14M5 12a2 2 0 01-2-2V7a2 2 0 012-2h14a2 2 0 012 2v3a2 2 0 01-2 2M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"></path>
                                </svg>
                                <span><?= e($unit['bathrooms']) ?> <?= e($t['bathrooms']) ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!empty($unit['description'])): ?>
                        <p class="unit-description"><?= e($unit['description']) ?></p>
                        <?php endif; ?>
                        
                        <div class="unit-actions">
                            <button class="btn-detail" onclick="showUnitDetail(<?= htmlspecialchars(json_encode($unit), ENT_QUOTES) ?>)">
                                <?= e($t['view_detail']) ?>
                            </button>
                            <a href="<?= $whatsappLink ?>" target="_blank" class="btn-whatsapp" rel="noopener">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                                </svg>
                                <?= e($t['contact_sales']) ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Unit Detail Modal -->
<div id="unit-modal" class="unit-modal" style="display: none;">
    <div class="modal-content">
        <button class="modal-close" onclick="closeUnitModal()">&times;</button>
        <div class="modal-body">
            <img id="modal-image" src="" alt="">
            <div class="modal-info">
                <h2 id="modal-title"></h2>
                <div id="modal-specs"></div>
                <p id="modal-description"></p>
                <div id="modal-price"></div>
                <div class="modal-actions">
                    <a id="modal-whatsapp" href="" target="_blank" class="btn-whatsapp-large">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                        </svg>
                        Hubungi Sales Sekarang
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Unit Types Additional Styles */
.unit-specs {
    display: flex;
    gap: 1rem;
    margin: 1rem 0;
    flex-wrap: wrap;
}

.spec-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.spec-item svg {
    color: var(--primary-color);
}

.unit-price {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: var(--radius-md);
    backdrop-filter: blur(10px);
}

.price-label {
    display: block;
    font-size: 0.75rem;
    opacity: 0.8;
}

.price-value {
    display: block;
    font-size: 1.1rem;
    font-weight: 700;
}

.unit-description {
    font-size: 0.95rem;
    color: var(--text-secondary);
    margin: 1rem 0;
}

.unit-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

.btn-whatsapp {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1.5rem;
    background: #25d366;
    color: white;
    border-radius: var(--radius-md);
    font-weight: 500;
    transition: all var(--transition-fast);
}

.btn-whatsapp:hover {
    background: #128c7e;
    transform: translateY(-2px);
    color: white;
}

/* Unit Modal */
.unit-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    padding: 1rem;
}

.modal-content {
    background: white;
    border-radius: var(--radius-lg);
    max-width: 900px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    animation: modalIn 0.3s ease;
}

@keyframes modalIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.modal-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: white;
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    font-size: 1.5rem;
    cursor: pointer;
    box-shadow: var(--shadow-md);
    z-index: 1;
}

.modal-body {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

.modal-body img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: var(--radius-lg) 0 0 var(--radius-lg);
}

.modal-info {
    padding: 2rem;
}

.btn-whatsapp-large {
    display: inline-flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 2rem;
    background: #25d366;
    color: white;
    border-radius: var(--radius-full);
    font-weight: 600;
    font-size: 1.1rem;
    transition: all var(--transition-normal);
    box-shadow: 0 4px 15px rgba(37, 211, 102, 0.3);
}

.btn-whatsapp-large:hover {
    background: #128c7e;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(37, 211, 102, 0.4);
    color: white;
}

/* Dark mode adjustments */
body.dark-theme .modal-content {
    background: var(--bg-dark);
    color: white;
}

body.dark-theme .modal-close {
    background: var(--bg-secondary);
    color: white;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .modal-body {
        grid-template-columns: 1fr;
    }
    
    .modal-body img {
        border-radius: var(--radius-lg) var(--radius-lg) 0 0;
        max-height: 300px;
    }
    
    .unit-actions {
        flex-direction: column;
    }
    
    .btn-whatsapp,
    .btn-detail {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
// Unit detail modal functions
function showUnitDetail(unit) {
    const modal = document.getElementById('unit-modal');
    const modalImage = document.getElementById('modal-image');
    const modalTitle = document.getElementById('modal-title');
    const modalSpecs = document.getElementById('modal-specs');
    const modalDescription = document.getElementById('modal-description');
    const modalPrice = document.getElementById('modal-price');
    const modalWhatsapp = document.getElementById('modal-whatsapp');
    
    // Set content
    modalImage.src = '<?= BASE_URL ?>uploads/unit-types/' + unit.image;
    modalImage.alt = unit.name;
    modalTitle.textContent = unit.name;
    
    // Build specs HTML
    let specsHTML = '<div class="unit-specs">';
    specsHTML += `<div class="spec-item">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="2" y="2" width="20" height="20" rx="2" ry="2"></rect>
            <line x1="7" y1="2" x2="7" y2="22"></line>
            <line x1="17" y1="2" x2="17" y2="22"></line>
            <line x1="2" y1="12" x2="22" y2="12"></line>
        </svg>
        <span>${unit.size} m²</span>
    </div>`;
    
    if (unit.bedrooms) {
        specsHTML += `<div class="spec-item">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
            <span>${unit.bedrooms} Kamar Tidur</span>
        </div>`;
    }
    
    if (unit.bathrooms) {
        specsHTML += `<div class="spec-item">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M5 12a2 2 0 01-2-2V7a2 2 0 012-2h14a2 2 0 012 2v3a2 2 0 01-2 2M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"></path>
            </svg>
            <span>${unit.bathrooms} Kamar Mandi</span>
        </div>`;
    }
    specsHTML += '</div>';
    
    modalSpecs.innerHTML = specsHTML;
    modalDescription.textContent = unit.description || '';
    
    if (unit.price) {
        modalPrice.innerHTML = `<div class="unit-price" style="position: static; background: var(--bg-secondary); color: var(--text-primary);">
            <span class="price-label">Mulai dari</span>
            <span class="price-value">${formatPrice(unit.price)}</span>
        </div>`;
    }
    
    // WhatsApp link
    const whatsappText = encodeURIComponent(`Halo, saya tertarik dengan ${unit.name} di Neo Green Terrace. Mohon informasi lebih lanjut.`);
    modalWhatsapp.href = `https://wa.me/<?= CONTACT_WHATSAPP ?>?text=${whatsappText}`;
    
    // Show modal
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    // Track modal view
    if (typeof trackClick === 'function') {
        trackClick(`Unit Detail View: ${unit.name}`, 'UNIT_DETAIL_VIEW', {
            unit_id: unit.id,
            unit_name: unit.name
        });
    }
}

function closeUnitModal() {
    const modal = document.getElementById('unit-modal');
    modal.style.display = 'none';
    document.body.style.overflow = '';
}

// Close modal on background click
document.getElementById('unit-modal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeUnitModal();
    }
});

// Close modal on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeUnitModal();
    }
});

// Price formatter
function formatPrice(price) {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(price);
}

// Track unit interactions
document.addEventListener('DOMContentLoaded', function() {
    // Track WhatsApp clicks
    document.querySelectorAll('.btn-whatsapp').forEach(btn => {
        btn.addEventListener('click', function() {
            const unitBox = this.closest('.unit-box');
            const unitName = unitBox.querySelector('h3').textContent;
            
            if (typeof trackClick === 'function') {
                trackClick(`Unit WhatsApp: ${unitName}`, 'UNIT_WHATSAPP', {
                    unit_name: unitName
                });
            }
        });
    });
});
</script>