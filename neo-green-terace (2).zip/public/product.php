<?php
// ================================
// Neo Green Terrace - Product Features
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get product features from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, description, icon 
        FROM product_features 
        WHERE is_active = 1 
        ORDER BY position ASC 
        LIMIT 6
    ");
    $stmt->execute();
    $features = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Product features error: ' . $e->getMessage());
    $features = [];
}

// Default features if none in database
if (empty($features)) {
    $features = [
        [
            'title' => 'Lokasi Strategis',
            'description' => 'Dekat dengan berbagai fasilitas umum, sekolah, dan pusat perbelanjaan',
            'icon' => 'location.svg'
        ],
        [
            'title' => 'Keamanan 24 Jam',
            'description' => 'Sistem keamanan terintegrasi dengan CCTV dan security 24/7',
            'icon' => 'security.svg'
        ],
        [
            'title' => 'Fasilitas Lengkap',
            'description' => 'Taman bermain, jogging track, dan area komunitas',
            'icon' => 'facilities.svg'
        ],
        [
            'title' => 'Desain Modern',
            'description' => 'Arsitektur contemporary dengan material berkualitas tinggi',
            'icon' => 'design.svg'
        ],
        [
            'title' => 'Bebas Banjir',
            'description' => 'Sistem drainase modern dan lokasi yang aman dari banjir',
            'icon' => 'flood-free.svg'
        ],
        [
            'title' => 'Investasi Menguntungkan',
            'description' => 'Nilai properti yang terus meningkat di lokasi strategis',
            'icon' => 'investment.svg'
        ]
    ];
}

// Language translations
$translations = [
    'id' => [
        'title' => 'Mengapa Memilih Neo Green Terrace?',
        'subtitle' => 'Keunggulan yang membuat hunian kami menjadi pilihan terbaik untuk keluarga Anda'
    ],
    'en' => [
        'title' => 'Why Choose Neo Green Terrace?',
        'subtitle' => 'Advantages that make our residence the best choice for your family'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];
?>

<section id="product-features" class="product-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="features-grid">
            <?php foreach ($features as $index => $feature): 
                $iconPath = upload_url('product-icons/' . $feature['icon']);
                $defaultIcon = asset_url('public/assets/icons/default-feature.svg');
            ?>
                <div class="feature-box" data-aos="fade-up" data-aos-delay="<?= $index * 100 ?>">
                    <div class="feature-icon">
                        <img 
                            src="<?= $iconPath ?>" 
                            alt="<?= e($feature['title']) ?>"
                            onerror="this.onerror=null; this.src='<?= $defaultIcon ?>'">
                    </div>
                    <h3><?= e($feature['title']) ?></h3>
                    <p><?= e($feature['description']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<style>
/* Product Features Additional Styles */
.section-header {
    text-align: center;
    margin-bottom: 3rem;
}

.section-subtitle {
    font-size: 1.1rem;
    color: var(--text-secondary);
    max-width: 600px;
    margin: 1rem auto 0;
    line-height: 1.8;
}

.feature-box {
    position: relative;
    overflow: hidden;
}

.feature-box::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
    border-radius: var(--radius-lg);
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: -1;
}

.feature-box:hover::before {
    opacity: 1;
}

.feature-box:hover {
    background: white;
    color: var(--text-primary);
}

.feature-box:hover .feature-icon {
    transform: scale(1.1) rotate(5deg);
    background: white;
}

.feature-box:hover .feature-icon img {
    filter: none;
}

/* Dark mode adjustments */
body.dark-theme .feature-box:hover {
    background: var(--bg-dark);
    color: white;
}

body.dark-theme .feature-box:hover .feature-icon {
    background: var(--primary-color);
}

/* Animation on scroll */
@keyframes fadeInScale {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.feature-box.aos-animate {
    animation: fadeInScale 0.6s ease forwards;
}

/* Mobile optimizations */
@media (max-width: 768px) {
    .features-grid {
        gap: 1.5rem;
    }
    
    .feature-box {
        padding: 1.5rem;
    }
    
    .feature-icon {
        width: 60px;
        height: 60px;
    }
    
    .feature-icon img {
        width: 35px;
        height: 35px;
    }
}
</style>

<script>
// Initialize AOS (Animate On Scroll) if not already initialized
if (typeof AOS === 'undefined') {
    // Load AOS CSS
    const aosCSS = document.createElement('link');
    aosCSS.rel = 'stylesheet';
    aosCSS.href = 'https://unpkg.com/aos@2.3.1/dist/aos.css';
    document.head.appendChild(aosCSS);
    
    // Load AOS JS
    const aosJS = document.createElement('script');
    aosJS.src = 'https://unpkg.com/aos@2.3.1/dist/aos.js';
    aosJS.onload = function() {
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });
    };
    document.body.appendChild(aosJS);
} else {
    // Refresh AOS for new elements
    AOS.refresh();
}

// Track feature box interactions
document.addEventListener('DOMContentLoaded', function() {
    const featureBoxes = document.querySelectorAll('.feature-box');
    
    featureBoxes.forEach((box, index) => {
        // Track hover
        box.addEventListener('mouseenter', function() {
            const title = this.querySelector('h3').textContent;
            if (typeof trackClick === 'function') {
                trackClick(`Feature Hover: ${title}`, 'FEATURE_HOVER', {
                    feature_index: index
                });
            }
        });
        
        // Make entire box clickable
        box.style.cursor = 'pointer';
        box.addEventListener('click', function() {
            const title = this.querySelector('h3').textContent;
            const description = this.querySelector('p').textContent;
            
            // Track click
            if (typeof trackClick === 'function') {
                trackClick(`Feature Click: ${title}`, 'FEATURE_CLICK', {
                    feature_index: index
                });
            }
            
            // Optional: Show more info in a modal
            // showFeatureModal(title, description);
        });
    });
});

// Optional: Feature modal function
function showFeatureModal(title, description) {
    // Create modal element
    const modal = document.createElement('div');
    modal.className = 'feature-modal';
    modal.innerHTML = `
        <div class="feature-modal-content">
            <button class="modal-close">&times;</button>
            <h3>${title}</h3>
            <p>${description}</p>
            <a href="#unit-types" class="btn-cta">Lihat Tipe Unit</a>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.className === 'modal-close') {
            modal.remove();
        }
    });
    
    // Animate in
    setTimeout(() => modal.classList.add('show'), 10);
}
</script>