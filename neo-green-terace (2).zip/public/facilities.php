<?php
// ================================
// Neo Green Terrace - Facilities Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get facilities from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, description, icon 
        FROM facilities 
        WHERE is_active = 1 
        ORDER BY priority ASC
    ");
    $stmt->execute();
    $facilities = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Facilities section error: ' . $e->getMessage());
    $facilities = [];
}

// Default facilities if none in database
if (empty($facilities)) {
    $facilities = [
        [
            'title' => 'Taman Bermain Anak',
            'description' => 'Area bermain yang aman dan menyenangkan untuk anak-anak',
            'icon' => 'playground.svg'
        ],
        [
            'title' => 'Jogging Track',
            'description' => 'Jalur jogging dengan pemandangan asri untuk kesehatan Anda',
            'icon' => 'jogging.svg'
        ],
        [
            'title' => 'Keamanan 24 Jam',
            'description' => 'Sistem keamanan dengan CCTV dan security profesional',
            'icon' => 'security.svg'
        ],
        [
            'title' => 'Area Parkir Luas',
            'description' => 'Tempat parkir yang luas untuk kendaraan penghuni dan tamu',
            'icon' => 'parking.svg'
        ],
        [
            'title' => 'Musholla',
            'description' => 'Tempat ibadah yang nyaman untuk penghuni muslim',
            'icon' => 'mosque.svg'
        ],
        [
            'title' => 'Taman Hijau',
            'description' => 'Area hijau yang asri untuk relaksasi dan udara segar',
            'icon' => 'park.svg'
        ],
        [
            'title' => 'Gazebo',
            'description' => 'Tempat berkumpul dan bersosialisasi dengan tetangga',
            'icon' => 'gazebo.svg'
        ],
        [
            'title' => 'Sistem Drainase Modern',
            'description' => 'Drainase yang baik untuk mencegah genangan air',
            'icon' => 'drainage.svg'
        ]
    ];
}

// Language translations
$translations = [
    'id' => [
        'title' => 'Fasilitas Lengkap',
        'subtitle' => 'Nikmati berbagai fasilitas modern untuk kenyamanan hidup Anda'
    ],
    'en' => [
        'title' => 'Complete Facilities',
        'subtitle' => 'Enjoy various modern facilities for your comfortable living'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];
?>

<section id="facilities" class="facility-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="facility-grid">
            <?php foreach ($facilities as $index => $facility): 
                $iconPath = upload_url('facilities/' . $facility['icon']);
                $defaultIcon = asset_url('public/assets/icons/facility-default.svg');
                $delay = min($index * 100, 400);
            ?>
                <div class="facility-card" data-aos="fade-up" data-aos-delay="<?= $delay ?>">
                    <div class="facility-icon-wrapper">
                        <div class="facility-icon">
                            <img 
                                src="<?= $iconPath ?>" 
                                alt="<?= e($facility['title']) ?>"
                                loading="lazy"
                                onerror="this.onerror=null; this.src='<?= $defaultIcon ?>'">
                        </div>
                        <div class="icon-bg"></div>
                    </div>
                    
                    <h3><?= e($facility['title']) ?></h3>
                    <p><?= e($facility['description']) ?></p>
                    
                    <div class="facility-hover-effect">
                        <div class="hover-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Additional Info -->
        <div class="facility-extra" data-aos="fade-up" data-aos-delay="500">
            <div class="extra-content">
                <h3>Fasilitas Terdekat</h3>
                <div class="nearby-facilities">
                    <div class="nearby-item">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                        </svg>
                        <span>Rumah Sakit (5 menit)</span>
                    </div>
                    <div class="nearby-item">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 14l9-5-9-5-9 5 9 5z"/>
                            <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"/>
                        </svg>
                        <span>Sekolah (10 menit)</span>
                    </div>
                    <div class="nearby-item">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        <span>Pusat Perbelanjaan (15 menit)</span>
                    </div>
                    <div class="nearby-item">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <span>Stasiun Kereta (20 menit)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Facilities Additional Styles */
.facility-card {
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.facility-icon-wrapper {
    position: relative;
    margin-bottom: 1.5rem;
}

.facility-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    border-radius: 50%;
    position: relative;
    z-index: 2;
    transition: all var(--transition-normal);
}

.facility-icon img {
    width: 48px;
    height: 48px;
    filter: none;
}

.icon-bg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100px;
    height: 100px;
    background: var(--primary-color);
    opacity: 0.1;
    border-radius: 50%;
    transition: all var(--transition-normal);
}

.facility-card:hover .icon-bg {
    transform: translate(-50%, -50%) scale(1.2);
    opacity: 0.2;
}

.facility-card:hover .facility-icon {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 168, 107, 0.3);
}

.facility-hover-effect {
    position: absolute;
    top: 0;
    right: 0;
    width: 60px;
    height: 60px;
    background: var(--primary-color);
    transform: translate(30px, -30px) rotate(45deg);
    transition: all var(--transition-normal);
    opacity: 0;
}

.facility-card:hover .facility-hover-effect {
    transform: translate(15px, -15px) rotate(45deg);
    opacity: 1;
}

.hover-icon {
    position: absolute;
    bottom: 8px;
    left: 8px;
    color: white;
    transform: rotate(-45deg);
}

/* Extra Info Section */
.facility-extra {
    margin-top: 4rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-xl);
    padding: 3rem;
    text-align: center;
}

.extra-content h3 {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    color: var(--text-primary);
}

.nearby-facilities {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 2rem;
    max-width: 800px;
    margin: 0 auto;
}

.nearby-item {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
}

.nearby-item svg {
    color: var(--primary-color);
}

.nearby-item span {
    font-size: 0.95rem;
    color: var(--text-secondary);
}

/* Animation for cards */
@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-10px);
    }
}

.facility-card:hover {
    animation: float 2s ease-in-out infinite;
}

/* Glassmorphism effect on hover */
.facility-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
    opacity: 0;
    transition: opacity var(--transition-normal);
    pointer-events: none;
}

.facility-card:hover::before {
    opacity: 1;
}

/* Dark mode adjustments */
body.dark-theme .facility-icon {
    background: var(--bg-secondary);
}

body.dark-theme .facility-extra {
    background: var(--bg-dark);
}

/* Mobile adjustments */
@media (max-width: 768px) {
    .facility-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 1rem;
    }
    
    .facility-card {
        padding: 1.5rem 1rem;
    }
    
    .facility-icon {
        width: 60px;
        height: 60px;
    }
    
    .facility-icon img {
        width: 36px;
        height: 36px;
    }
    
    .icon-bg {
        width: 80px;
        height: 80px;
    }
    
    .facility-card h3 {
        font-size: 1rem;
    }
    
    .facility-card p {
        font-size: 0.85rem;
    }
    
    .nearby-facilities {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}
</style>

<script>
// Facilities interaction
document.addEventListener('DOMContentLoaded', function() {
    const facilityCards = document.querySelectorAll('.facility-card');
    
    // Add interactive hover effect
    facilityCards.forEach((card, index) => {
        // Track hover
        card.addEventListener('mouseenter', function() {
            const title = this.querySelector('h3').textContent;
            if (typeof trackClick === 'function') {
                trackClick(`Facility Hover: ${title}`, 'FACILITY_HOVER');
            }
        });
        
        // Click interaction
        card.addEventListener('click', function() {
            const title = this.querySelector('h3').textContent;
            const description = this.querySelector('p').textContent;
            
            // Add ripple effect
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
            
            // Track click
            if (typeof trackClick === 'function') {
                trackClick(`Facility Click: ${title}`, 'FACILITY_CLICK');
            }
            
            // Optional: Show more info in modal
            // showFacilityModal(title, description);
        });
    });
    
    // Parallax effect on scroll
    const facilitySection = document.querySelector('.facility-section');
    const iconBgs = document.querySelectorAll('.icon-bg');
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.1;
        
        if (isInViewport(facilitySection)) {
            iconBgs.forEach((bg, index) => {
                const speed = 1 + (index * 0.1);
                bg.style.transform = `translate(-50%, calc(-50% + ${rate * speed}px)) scale(1)`;
            });
        }
    });
    
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    // Nearby facilities animation
    const nearbyItems = document.querySelectorAll('.nearby-item');
    nearbyItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.1}s`;
        item.classList.add('fade-in');
    });
});

// Ripple effect styles
const style = document.createElement('style');
style.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(0, 168, 107, 0.3);
        width: 100px;
        height: 100px;
        margin-top: -50px;
        margin-left: -50px;
        animation: ripple-animation 0.6s;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        from {
            transform: scale(0);
            opacity: 1;
        }
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
</script>