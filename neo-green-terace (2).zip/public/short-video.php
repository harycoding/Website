<?php
// ================================
// Neo Green Terrace - Video Short Section
// ================================

// Proteksi akses langsung
if (!defined('NEO_GREEN_ACCESS')) {
    die("Direct access not allowed.");
}

// Get short videos from database
try {
    $stmt = $pdo->prepare("
        SELECT id, title, filename, thumbnail, duration, views 
        FROM short_videos 
        WHERE is_active = 1 
        ORDER BY created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $shortVideos = $stmt->fetchAll();
} catch (PDOException $e) {
    log_error('Video short section error: ' . $e->getMessage());
    $shortVideos = [];
}

// Default videos if none in database
if (empty($shortVideos)) {
    $shortVideos = [
        ['id' => 1, 'title' => 'Tour Virtual Neo Green Terrace', 'filename' => 'short-1.mp4', 'thumbnail' => 'thumb-1.jpg'],
        ['id' => 2, 'title' => 'Fasilitas Lengkap', 'filename' => 'short-2.mp4', 'thumbnail' => 'thumb-2.jpg'],
        ['id' => 3, 'title' => 'Testimoni Penghuni', 'filename' => 'short-3.mp4', 'thumbnail' => 'thumb-3.jpg']
    ];
}

// Language translations
$translations = [
    'id' => [
        'title' => 'Video Singkat',
        'subtitle' => 'Jelajahi Neo Green Terrace melalui video singkat kami',
        'views' => 'x ditonton',
        'play' => 'Putar video'
    ],
    'en' => [
        'title' => 'Short Videos',
        'subtitle' => 'Explore Neo Green Terrace through our short videos',
        'views' => 'views',
        'play' => 'Play video'
    ]
];

$lang = $_SESSION['lang'] ?? 'id';
$t = $translations[$lang] ?? $translations['id'];

// Format view count
function formatViews($views, $lang = 'id') {
    if ($views < 1000) {
        return $views . ' ' . ($lang === 'id' ? 'x ditonton' : 'views');
    } elseif ($views < 1000000) {
        return number_format($views / 1000, 1) . 'K ' . ($lang === 'id' ? 'x ditonton' : 'views');
    } else {
        return number_format($views / 1000000, 1) . 'M ' . ($lang === 'id' ? 'x ditonton' : 'views');
    }
}
?>

<section id="short-video" class="short-video-section">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <h2 class="section-title"><?= e($t['title']) ?></h2>
            <p class="section-subtitle"><?= e($t['subtitle']) ?></p>
        </div>
        
        <div class="short-video-container">
            <div class="short-video-scroll" id="short-video-scroll">
                <?php foreach ($shortVideos as $index => $video): 
                    $videoPath = upload_url('video-short/' . $video['filename']);
                    $thumbnailPath = upload_url('video-short/' . $video['thumbnail']);
                    $defaultThumb = asset_url('public/assets/images/video-thumb-default.jpg');
                ?>
                    <div class="short-video-card" data-aos="zoom-in" data-aos-delay="<?= min($index * 50, 300) ?>">
                        <div class="video-wrapper">
                            <video 
                                class="short-video" 
                                poster="<?= $thumbnailPath ?>"
                                preload="metadata"
                                muted
                                loop
                                playsinline
                                disablePictureInPicture
                                controlsList="nodownload"
                                data-video-id="<?= $video['id'] ?>"
                                oncontextmenu="return false;">
                                <source src="<?= $videoPath ?>" type="video/mp4">
                                <source src="<?= str_replace('.mp4', '.webm', $videoPath) ?>" type="video/webm">
                            </video>
                            
                            <!-- Custom Controls Overlay -->
                            <div class="video-overlay">
                                <button class="play-btn" aria-label="<?= e($t['play']) ?>">
                                    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M8 5v14l11-7z"/>
                                    </svg>
                                </button>
                                
                                <!-- Progress Bar -->
                                <div class="video-progress">
                                    <div class="progress-bar"></div>
                                </div>
                                
                                <!-- Video Info -->
                                <div class="video-info">
                                    <h4><?= e($video['title']) ?></h4>
                                    <?php if (!empty($video['views'])): ?>
                                    <span class="video-views"><?= formatViews($video['views'], $lang) ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Actions -->
                                <div class="video-actions">
                                    <button class="action-btn like-btn" aria-label="Like">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
                                        </svg>
                                    </button>
                                    <button class="action-btn share-btn" aria-label="Share">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <circle cx="18" cy="5" r="3"></circle>
                                            <circle cx="6" cy="12" r="3"></circle>
                                            <circle cx="18" cy="19" r="3"></circle>
                                            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                                            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                                        </svg>
                                    </button>
                                    <button class="action-btn fullscreen-btn" aria-label="Fullscreen">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Loading Spinner -->
                            <div class="video-loading">
                                <div class="spinner"></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Navigation Arrows -->
            <button class="video-nav video-nav-prev" aria-label="Previous video">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <button class="video-nav video-nav-next" aria-label="Next video">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
        </div>
    </div>
</section>

<style>
/* Video Short Additional Styles */
.short-video-container {
    position: relative;
    max-width: 1200px;
    margin: 0 auto;
}

.video-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    background: #000;
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.short-video {
    width: 100%;
    height: 400px;
    object-fit: cover;
}

.video-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, transparent 50%, rgba(0,0,0,0.7) 100%);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    opacity: 1;
    transition: opacity var(--transition-normal);
}

.short-video-card.playing .video-overlay {
    opacity: 0;
}

.short-video-card:hover .video-overlay {
    opacity: 1;
}

.play-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(255, 255, 255, 0.9);
    border: none;
    width: 64px;
    height: 64px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all var(--transition-fast);
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.play-btn:hover {
    background: white;
    transform: translate(-50%, -50%) scale(1.1);
}

.short-video-card.playing .play-btn {
    display: none;
}

.video-progress {
    position: absolute;
    bottom: 60px;
    left: 0;
    right: 0;
    height: 3px;
    background: rgba(255, 255, 255, 0.3);
    cursor: pointer;
}

.progress-bar {
    height: 100%;
    background: var(--primary-color);
    width: 0;
    transition: width 0.1s linear;
}

.video-info {
    position: absolute;
    bottom: 70px;
    left: 1rem;
    right: 1rem;
    color: white;
}

.video-info h4 {
    font-size: 1rem;
    margin-bottom: 0.25rem;
    color: white;
}

.video-views {
    font-size: 0.875rem;
    opacity: 0.8;
}

.video-actions {
    position: absolute;
    bottom: 1rem;
    right: 1rem;
    display: flex;
    gap: 0.5rem;
}

.action-btn {
    background: rgba(255, 255, 255, 0.1);
    border: none;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    backdrop-filter: blur(10px);
    transition: all var(--transition-fast);
    color: white;
}

.action-btn:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: scale(1.1);
}

.action-btn.active {
    background: var(--primary-color);
}

.video-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: none;
}

.short-video-card.loading .video-loading {
    display: block;
}

.spinner {
    width: 40px;
    height: 40px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

/* Navigation arrows */
.video-nav {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(255, 255, 255, 0.9);
    border: none;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: var(--shadow-md);
    transition: all var(--transition-fast);
    z-index: 10;
}

.video-nav:hover {
    background: white;
    box-shadow: var(--shadow-lg);
}

.video-nav-prev {
    left: -24px;
}

.video-nav-next {
    right: -24px;
}

/* Dark mode adjustments */
body.dark-theme .play-btn {
    background: rgba(45, 45, 45, 0.9);
}

body.dark-theme .action-btn {
    background: rgba(45, 45, 45, 0.5);
}

/* Mobile adjustments */
@media (max-width: 768px) {
    .short-video {
        height: 500px;
    }
    
    .video-nav {
        display: none;
    }
    
    .video-info h4 {
        font-size: 0.9rem;
    }
}
</style>

<script>
// Video Short functionality
document.addEventListener('DOMContentLoaded', function() {
    const videoScroll = document.getElementById('short-video-scroll');
    const videos = document.querySelectorAll('.short-video');
    const prevBtn = document.querySelector('.video-nav-prev');
    const nextBtn = document.querySelector('.video-nav-next');
    let currentVideo = null;
    
    // Horizontal scroll navigation
    if (videoScroll && prevBtn && nextBtn) {
        const scrollAmount = 300;
        
        prevBtn.addEventListener('click', () => {
            videoScroll.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });
        
        nextBtn.addEventListener('click', () => {
            videoScroll.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });
    }
    
    // Video player functionality
    videos.forEach(video => {
        const card = video.closest('.short-video-card');
        const playBtn = card.querySelector('.play-btn');
        const progressBar = card.querySelector('.progress-bar');
        const likeBtn = card.querySelector('.like-btn');
        const shareBtn = card.querySelector('.share-btn');
        const fullscreenBtn = card.querySelector('.fullscreen-btn');
        const videoId = video.dataset.videoId;
        
        // Play/Pause functionality
        function togglePlay() {
            if (video.paused) {
                // Pause other videos
                if (currentVideo && currentVideo !== video) {
                    currentVideo.pause();
                    currentVideo.closest('.short-video-card').classList.remove('playing');
                }
                
                video.play();
                card.classList.add('playing');
                currentVideo = video;
                
                // Track video play
                if (typeof trackVideo === 'function') {
                    trackVideo(videoId, 'short', 'play');
                }
            } else {
                video.pause();
                card.classList.remove('playing');
            }
        }
        
        playBtn.addEventListener('click', togglePlay);
        video.addEventListener('click', togglePlay);
        
        // Progress bar update
        video.addEventListener('timeupdate', () => {
            const progress = (video.currentTime / video.duration) * 100;
            progressBar.style.width = progress + '%';
        });
        
        // Progress bar seek
        const progressContainer = card.querySelector('.video-progress');
        progressContainer.addEventListener('click', (e) => {
            const rect = progressContainer.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const percentage = x / rect.width;
            video.currentTime = percentage * video.duration;
        });
        
        // Video ended
        video.addEventListener('ended', () => {
            card.classList.remove('playing');
            video.currentTime = 0;
            
            // Track video complete
            if (typeof trackVideo === 'function') {
                trackVideo(videoId, 'short', 'end', video.duration);
            }
        });
        
        // Like button
        likeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            likeBtn.classList.toggle('active');
            
            if (typeof trackClick === 'function') {
                trackClick(`Video Like: ${videoId}`, 'VIDEO_LIKE');
            }
        });
        
        // Share button
        shareBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const shareUrl = window.location.href + '#video-' + videoId;
            
            if (navigator.share) {
                navigator.share({
                    title: 'Neo Green Terrace',
                    text: card.querySelector('h4').textContent,
                    url: shareUrl
                });
            } else {
                // Copy to clipboard
                navigator.clipboard.writeText(shareUrl).then(() => {
                    alert('Link copied to clipboard!');
                });
            }
            
            if (typeof trackClick === 'function') {
                trackClick(`Video Share: ${videoId}`, 'VIDEO_SHARE');
            }
        });
        
        // Fullscreen button
        fullscreenBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            
            if (video.requestFullscreen) {
                video.requestFullscreen();
            } else if (video.webkitRequestFullscreen) {
                video.webkitRequestFullscreen();
            } else if (video.msRequestFullscreen) {
                video.msRequestFullscreen();
            }
            
            if (typeof trackClick === 'function') {
                trackClick(`Video Fullscreen: ${videoId}`, 'VIDEO_FULLSCREEN');
            }
        });
        
        // Loading state
        video.addEventListener('loadstart', () => {
            card.classList.add('loading');
        });
        
        video.addEventListener('canplay', () => {
            card.classList.remove('loading');
        });
        
        // Auto-play on scroll (muted)
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                    video.play().catch(() => {
                        // Auto-play prevented
                    });
                } else {
                    video.pause();
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(video);
    });
    
    // Mouse wheel horizontal scroll
    if (videoScroll) {
        videoScroll.addEventListener('wheel', (e) => {
            if (e.deltaY !== 0) {
                e.preventDefault();
                videoScroll.scrollLeft += e.deltaY;
            }
        });
    }
});
</script>