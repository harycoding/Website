<?php
// ================================
// Neo Green Terrace - Admin Dashboard
// ================================
define('NEO_GREEN_ACCESS', true);

// Start session
session_start();

// Include required files
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../security/firewall.php';
require_once '../security/session-manager.php';

// Check admin authentication
checkAdminAuth();

// Get admin info
$adminName = $_SESSION['admin_name'] ?? $_SESSION['admin_username'];
$adminRole = $_SESSION['admin_role'] ?? 'admin';

// Get dashboard statistics
try {
    // Total visitors today
    $visitorStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ip_address) as total 
        FROM visitor_logs 
        WHERE DATE(created_at) = CURDATE()
    ");
    $visitorStmt->execute();
    $totalVisitorsToday = $visitorStmt->fetchColumn() ?: 0;
    
    // Total visitors this month
    $visitorMonthStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ip_address) as total 
        FROM visitor_logs 
        WHERE MONTH(created_at) = MONTH(CURDATE()) 
        AND YEAR(created_at) = YEAR(CURDATE())
    ");
    $visitorMonthStmt->execute();
    $totalVisitorsMonth = $visitorMonthStmt->fetchColumn() ?: 0;
    
    // Total clicks today
    $clickStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM click_logs 
        WHERE DATE(created_at) = CURDATE()
    ");
    $clickStmt->execute();
    $totalClicksToday = $clickStmt->fetchColumn() ?: 0;
    
    // Total video views
    $videoStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM video_logs 
        WHERE DATE(created_at) = CURDATE()
    ");
    $videoStmt->execute();
    $totalVideosToday = $videoStmt->fetchColumn() ?: 0;
    
    // Failed login attempts
    $failedLoginStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM security_logs 
        WHERE event_type = 'login_failed' 
        AND DATE(created_at) = CURDATE()
    ");
    $failedLoginStmt->execute();
    $failedLoginsToday = $failedLoginStmt->fetchColumn() ?: 0;
    
    // Get chart data for last 7 days
    $chartStmt = $pdo->prepare("
        SELECT 
            DATE(created_at) as date,
            COUNT(DISTINCT ip_address) as visitors
        FROM visitor_logs
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ");
    $chartStmt->execute();
    $chartData = $chartStmt->fetchAll();
    
    // Prepare chart arrays
    $chartLabels = [];
    $chartValues = [];
    
    // Fill in missing dates
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $chartLabels[] = date('d M', strtotime($date));
        
        $found = false;
        foreach ($chartData as $data) {
            if ($data['date'] === $date) {
                $chartValues[] = (int)$data['visitors'];
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            $chartValues[] = 0;
        }
    }
    
} catch (PDOException $e) {
    log_error('Dashboard stats error: ' . $e->getMessage());
    // Set default values on error
    $totalVisitorsToday = $totalVisitorsMonth = $totalClicksToday = $totalVideosToday = $failedLoginsToday = 0;
    $chartLabels = $chartValues = [];
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Neo Green Terrace Admin</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?= asset_url('public/assets/images/favicon.png') ?>">
    
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/admin-style.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="admin-dashboard">
    
    <!-- Sidebar -->
    <?php include 'modules/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="main-wrapper">
        <!-- Topbar -->
        <?php include 'modules/topbar.php'; ?>
        
        <!-- Dashboard Content -->
        <main class="main-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <p class="welcome-message">Selamat datang kembali, <?= e($adminName) ?>!</p>
            </div>
            
            <!-- Statistics Cards -->
            <section class="dashboard-cards">
                <div class="stat-card primary">
                    <div class="card-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                    <div class="card-content">
                        <h3>Pengunjung Hari Ini</h3>
                        <p class="stat-number" id="total-visitors"><?= number_format($totalVisitorsToday) ?></p>
                        <span class="stat-label">Unique visitors</span>
                    </div>
                </div>
                
                <div class="stat-card success">
                    <div class="card-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>
                    <div class="card-content">
                        <h3>Total Klik</h3>
                        <p class="stat-number" id="total-clicks"><?= number_format($totalClicksToday) ?></p>
                        <span class="stat-label">Interaksi hari ini</span>
                    </div>
                </div>
                
                <div class="stat-card info">
                    <div class="card-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="23 7 16 12 23 17 23 7"></polygon>
                            <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                        </svg>
                    </div>
                    <div class="card-content">
                        <h3>Video Ditonton</h3>
                        <p class="stat-number" id="total-videos"><?= number_format($totalVideosToday) ?></p>
                        <span class="stat-label">Views hari ini</span>
                    </div>
                </div>
                
                <div class="stat-card warning">
                    <div class="card-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                            <line x1="12" y1="9" x2="12" y2="13"></line>
                            <line x1="12" y1="17" x2="12.01" y2="17"></line>
                        </svg>
                    </div>
                    <div class="card-content">
                        <h3>Login Gagal</h3>
                        <p class="stat-number" id="failed-logins"><?= number_format($failedLoginsToday) ?></p>
                        <span class="stat-label">Percobaan hari ini</span>
                    </div>
                </div>
            </section>
            
            <!-- Charts Section -->
            <section class="dashboard-charts">
                <div class="chart-container">
                    <div class="chart-header">
                        <h2>Statistik Pengunjung 7 Hari Terakhir</h2>
                        <button class="btn-refresh" onclick="refreshChart()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="23 4 23 10 17 10"></polyline>
                                <polyline points="1 20 1 14 7 14"></polyline>
                                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                            </svg>
                            Refresh
                        </button>
                    </div>
                    <canvas id="visitorChart"></canvas>
                </div>
                
                <div class="chart-container">
                    <div class="chart-header">
                        <h2>Quick Stats</h2>
                    </div>
                    <div class="quick-stats">
                        <div class="quick-stat-item">
                            <span class="stat-label">Pengunjung Bulan Ini</span>
                            <span class="stat-value"><?= number_format($totalVisitorsMonth) ?></span>
                        </div>
                        <div class="quick-stat-item">
                            <span class="stat-label">Rata-rata Harian</span>
                            <span class="stat-value"><?= number_format($totalVisitorsMonth / date('j')) ?></span>
                        </div>
                        <div class="quick-stat-item">
                            <span class="stat-label">Bounce Rate</span>
                            <span class="stat-value">32.5%</span>
                        </div>
                        <div class="quick-stat-item">
                            <span class="stat-label">Avg. Duration</span>
                            <span class="stat-value">2m 45s</span>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Recent Activity -->
            <section class="recent-activity">
                <h2>Aktivitas Terkini</h2>
                <div class="activity-list">
                    <div class="activity-item">
                        <div class="activity-icon success">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div class="activity-content">
                            <p>Pengunjung baru dari Jakarta</p>
                            <span class="activity-time">2 menit yang lalu</span>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon info">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polygon points="23 7 16 12 23 17 23 7"></polygon>
                                <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                            </svg>
                        </div>
                        <div class="activity-content">
                            <p>Video "Tour Virtual" ditonton</p>
                            <span class="activity-time">5 menit yang lalu</span>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon warning">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="8" x2="12" y2="12"></line>
                                <line x1="12" y1="16" x2="12.01" y2="16"></line>
                            </svg>
                        </div>
                        <div class="activity-content">
                            <p>Percobaan login gagal terdeteksi</p>
                            <span class="activity-time">15 menit yang lalu</span>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>
    
    <!-- AI Chatbot -->
    <div class="ai-bubble" id="ai-bubble" onclick="toggleAIChat()">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
    </div>
    
    <div class="ai-chatbox" id="ai-chatbox">
        <div class="chat-header">
            <span>AI Assistant</span>
            <button onclick="toggleAIChat()" class="chat-close">&times;</button>
        </div>
        <div class="chat-messages" id="ai-messages">
            <div class="ai-message">
                <p>Halo! Ada yang bisa saya bantu?</p>
            </div>
        </div>
        <form class="chat-input" id="ai-form" onsubmit="sendAIMessage(event)">
            <input type="text" id="ai-input" placeholder="Ketik pesan..." autocomplete="off">
            <button type="submit">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
            </button>
        </form>
    </div>
    
    <!-- Scripts -->
    <script src="assets/js/admin-script.js"></script>
    <script>
        // Initialize visitor chart
        const ctx = document.getElementById('visitorChart').getContext('2d');
        const visitorChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($chartLabels) ?>,
                datasets: [{
                    label: 'Pengunjung',
                    data: <?= json_encode($chartValues) ?>,
                    borderColor: '#00a86b',
                    backgroundColor: 'rgba(0, 168, 107, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: '#00a86b',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        cornerRadius: 8,
                        titleFont: {
                            size: 14
                        },
                        bodyFont: {
                            size: 13
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            borderDash: [2, 2],
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            precision: 0,
                            font: {
                                size: 12
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 12
                            }
                        }
                    }
                }
            }
        });
        
        // Refresh chart
        function refreshChart() {
            fetch('api/get-chart-data.php')
                .then(res => res.json())
                .then(data => {
                    visitorChart.data.labels = data.labels;
                    visitorChart.data.datasets[0].data = data.values;
                    visitorChart.update();
                });
        }
        
        // Auto refresh every 30 seconds
        setInterval(() => {
            refreshDashboardData();
        }, 30000);
        
        function refreshDashboardData() {
            fetch('api/get-dashboard-summary.php')
                .then(res => res.json())
                .then(data => {
                    document.getElementById('total-visitors').textContent = data.total_visitors.toLocaleString();
                    document.getElementById('total-clicks').textContent = data.total_clicks.toLocaleString();
                    document.getElementById('total-videos').textContent = data.total_videos.toLocaleString();
                    document.getElementById('failed-logins').textContent = data.failed_logins.toLocaleString();
                });
        }
        
        // AI Chat functions
        function toggleAIChat() {
            const chatbox = document.getElementById('ai-chatbox');
            chatbox.classList.toggle('show');
            if (chatbox.classList.contains('show')) {
                document.getElementById('ai-input').focus();
            }
        }
        
        function sendAIMessage(e) {
            e.preventDefault();
            const input = document.getElementById('ai-input');
            const message = input.value.trim();
            
            if (!message) return;
            
            // Add user message
            const messagesDiv = document.getElementById('ai-messages');
            messagesDiv.innerHTML += `
                <div class="user-message">
                    <p>${escapeHtml(message)}</p>
                </div>
            `;
            
            input.value = '';
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
            
            // Show typing indicator
            messagesDiv.innerHTML += `
                <div class="ai-message typing">
                    <p>Sedang mengetik...</p>
                </div>
            `;
            
            // Send to AI API
            fetch('api/ai-process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            })
            .then(res => res.json())
            .then(data => {
                // Remove typing indicator
                const typing = messagesDiv.querySelector('.typing');
                if (typing) typing.remove();
                
                // Add AI response
                messagesDiv.innerHTML += `
                    <div class="ai-message">
                        <p>${data.response}</p>
                    </div>
                `;
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            })
            .catch(err => {
                const typing = messagesDiv.querySelector('.typing');
                if (typing) typing.remove();
                
                messagesDiv.innerHTML += `
                    <div class="ai-message">
                        <p>Maaf, terjadi kesalahan. Silakan coba lagi.</p>
                    </div>
                `;
            });
        }
        
        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        }
    </script>
</body>
</html>