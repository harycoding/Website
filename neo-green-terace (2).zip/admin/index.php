<?php
// ================================
// Neo Green Terrace - Admin Login
// ================================
define('NEO_GREEN_ACCESS', true);

// Start session
session_start();

// Include required files
require_once '../config/config.php';
require_once '../config/db.php';
require_once '../security/firewall.php';
require_once '../security/csrf-protection.php';
require_once '../security/rate-limiter.php';

// Redirect to dashboard if already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    redirect('dashboard.php');
    exit();
}

// Initialize variables
$login_error = '';
$username = '';

// Check for timeout message
if (isset($_GET['timeout'])) {
    $login_error = 'Sesi Anda telah berakhir karena tidak aktif.';
}

// Check for logout message
if (isset($_GET['logout']) && $_GET['logout'] === 'success') {
    $login_error = 'Anda telah berhasil keluar.';
}

// Process login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $login_error = 'Token keamanan tidak valid. Silakan coba lagi.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Check rate limiting
        $rateLimiter = new RateLimiter();
        $ip = $_SERVER['REMOTE_ADDR'];
        
        if (!$rateLimiter->checkLimit($ip, 'login', 5, 300)) {
            $login_error = 'Terlalu banyak percobaan login. Silakan coba lagi dalam 5 menit.';
            log_activity('login_blocked', "Too many login attempts from IP: $ip");
        } else {
            // Validate input
            if (empty($username) || empty($password)) {
                $login_error = 'Username dan password harus diisi.';
            } else {
                // Check credentials
                try {
                    $stmt = $pdo->prepare("SELECT id, username, password, full_name, role, is_active FROM admin_users WHERE username = ? OR email = ?");
                    $stmt->execute([$username, $username]);
                    $user = $stmt->fetch();
                    
                    if ($user && password_verify($password, $user['password'])) {
                        // Check if account is active
                        if (!$user['is_active']) {
                            $login_error = 'Akun Anda tidak aktif. Hubungi administrator.';
                            log_activity('login_inactive', "Inactive account login attempt: $username", $username);
                        } else {
                            // Login successful
                            $_SESSION['admin_logged_in'] = true;
                            $_SESSION['admin_id'] = $user['id'];
                            $_SESSION['admin_username'] = $user['username'];
                            $_SESSION['admin_name'] = $user['full_name'];
                            $_SESSION['admin_role'] = $user['role'];
                            $_SESSION['login_time'] = time();
                            $_SESSION['last_activity'] = time();
                            
                            // Update last login
                            $updateStmt = $pdo->prepare("UPDATE admin_users SET last_login = NOW(), last_ip = ? WHERE id = ?");
                            $updateStmt->execute([$ip, $user['id']]);
                            
                            // Log successful login
                            log_activity('login_success', "Admin login successful", $user['username']);
                            
                            // Redirect to dashboard
                            redirect('dashboard.php');
                            exit();
                        }
                    } else {
                        $login_error = 'Username atau password salah.';
                        log_activity('login_failed', "Failed login attempt for: $username");
                        
                        // Record failed attempt
                        $rateLimiter->recordAttempt($ip, 'login');
                    }
                } catch (PDOException $e) {
                    $login_error = 'Terjadi kesalahan sistem. Silakan coba lagi.';
                    log_error('Login error: ' . $e->getMessage());
                }
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Login Admin - Neo Green Terrace</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?= asset_url('public/assets/images/favicon.png') ?>">
    
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/admin-style.css">
    
    <style>
        /* Login Page Specific Styles */
        body.login-page {
            background: linear-gradient(135deg, #00a86b 0%, #006d5b 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }
        
        .login-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            padding: 40px;
            animation: slideIn 0.5s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-logo {
            height: 60px;
            margin-bottom: 20px;
        }
        
        .login-header h2 {
            color: #2c3e50;
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }
        
        .login-error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
            animation: shake 0.5s ease;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        .login-success {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        
        .login-form label {
            display: block;
            color: #555;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .login-form input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .login-form input:focus {
            outline: none;
            border-color: #00a86b;
            box-shadow: 0 0 0 3px rgba(0,168,107,0.1);
        }
        
        .login-form button {
            width: 100%;
            padding: 14px;
            background: #00a86b;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .login-form button:hover {
            background: #006d5b;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0,168,107,0.3);
        }
        
        .login-form button:active {
            transform: translateY(0);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 30px;
            color: rgba(255,255,255,0.8);
            font-size: 14px;
        }
        
        .password-toggle {
            position: relative;
        }
        
        .password-toggle button {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 14px;
            padding: 5px;
        }
        
        .password-toggle button:hover {
            color: #555;
        }
        
        /* Loading state */
        .login-form.loading button {
            opacity: 0.7;
            pointer-events: none;
        }
        
        .login-form.loading button::after {
            content: '';
            display: inline-block;
            width: 14px;
            height: 14px;
            margin-left: 8px;
            border: 2px solid #fff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <img src="<?= upload_url('logo/logo.png') ?>" alt="Logo" class="login-logo" onerror="this.src='<?= asset_url('public/assets/images/logo.png') ?>'">
                <h2>Login Admin</h2>
            </div>
            
            <?php if ($login_error): ?>
                <div class="login-error"><?= e($login_error) ?></div>
            <?php endif; ?>
            
            <?php if (isset($_GET['logout']) && $_GET['logout'] === 'success'): ?>
                <div class="login-success">Anda telah berhasil keluar.</div>
            <?php endif; ?>
            
            <form method="post" class="login-form" id="loginForm">
                <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">
                
                <div class="form-group">
                    <label for="username">Username atau Email</label>
                    <input type="text" 
                           name="username" 
                           id="username" 
                           value="<?= e($username) ?>"
                           required 
                           autocomplete="username"
                           autofocus>
                </div>
                
                <div class="form-group password-toggle">
                    <label for="password">Password</label>
                    <input type="password" 
                           name="password" 
                           id="password" 
                           required 
                           autocomplete="current-password">
                    <button type="button" id="togglePassword" tabindex="-1">Show</button>
                </div>
                
                <button type="submit" id="loginButton">
                    <span>Masuk</span>
                </button>
            </form>
        </div>
        
        <footer class="login-footer">
            &copy; <?= date('Y') ?> Neo Green Terrace. All rights reserved.
        </footer>
    </div>

    <script>
        // Password toggle
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.textContent = type === 'password' ? 'Show' : 'Hide';
        });
        
        // Form submission
        const loginForm = document.getElementById('loginForm');
        const loginButton = document.getElementById('loginButton');
        
        loginForm.addEventListener('submit', function(e) {
            // Add loading state
            loginForm.classList.add('loading');
            loginButton.innerHTML = '<span>Memproses</span>';
            
            // Validate form
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            if (!username || !password) {
                e.preventDefault();
                loginForm.classList.remove('loading');
                loginButton.innerHTML = '<span>Masuk</span>';
                alert('Username dan password harus diisi.');
                return false;
            }
        });
        
        // Auto-focus on username field
        window.addEventListener('load', function() {
            document.getElementById('username').focus();
        });
        
        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>