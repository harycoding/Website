<?php
// ================================
// Neo Green Terrace - Public Index
// ================================
// Define constant for internal access
define('NEO_GREEN_ACCESS', true);

// Start session
session_start();

// Include config & DB
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';

// Include security (firewall protection)
require_once __DIR__ . '/security/firewall.php';

// Multibahasa & tema
$lang = $_SESSION['lang'] ?? 'id';
$theme = $_SESSION['theme'] ?? 'light';

// Handle language/theme changes
if (isset($_GET['lang']) && in_array($_GET['lang'], ['id', 'en', 'jp', 'kr', 'cn'])) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit();
}
if (isset($_GET['theme']) && in_array($_GET['theme'], ['light', 'dark'])) {
    $_SESSION['theme'] = $_GET['theme'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit();
}

// HTML starts
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Neo Green Terrace - Hunian Modern, Nyaman & Strategis di Indramayu">
    <meta name="keywords" content="perumahan indramayu, rumah dijual, neo green terrace, properti">
    <meta name="author" content="PT Rekana Dalan Terpercaya">
    
    <!-- Open Graph Meta -->
    <meta property="og:title" content="Neo Green Terrace | Hunian Modern & Nyaman">
    <meta property="og:description" content="Hunian modern dengan fasilitas lengkap di lokasi strategis Indramayu">
    <meta property="og:image" content="<?= asset_url('public/assets/images/og-image.jpg') ?>">
    <meta property="og:url" content="<?= BASE_URL ?>">
    <meta property="og:type" content="website">
    
    <title>Neo Green Terrace | Hunian Modern & Nyaman</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?= asset_url('public/assets/images/favicon.png') ?>">
    <link rel="apple-touch-icon" href="<?= asset_url('public/assets/images/apple-touch-icon.png') ?>">
    
    <!-- CSS Files -->
    <link rel="stylesheet" href="<?= asset_url('public/assets/css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('public/assets/css/responsive.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('public/assets/css/animations.css') ?>">
    
    <!-- Theme CSS -->
    <?php if ($theme === 'dark'): ?>
    <link rel="stylesheet" href="<?= asset_url('public/assets/css/dark-theme.css') ?>">
    <?php endif; ?>
    
    <!-- PWA Support -->
    <link rel="manifest" href="<?= asset_url('manifest.json') ?>">
    <meta name="theme-color" content="#00a86b">
    
    <!-- Preload critical resources -->
    <link rel="preload" href="<?= asset_url('public/assets/css/style.css') ?>" as="style">
    <link rel="preload" href="<?= asset_url('public/assets/js/script.js') ?>" as="script">
</head>
<body class="<?= $theme ?>-theme" data-lang="<?= $lang ?>">
    
    <!-- Loading Screen -->
    <div id="loading-screen" class="loading-screen">
        <div class="loader"></div>
    </div>
    
    <!-- Skip to content for accessibility -->
    <a href="#main-content" class="skip-link">Skip to main content</a>
    
    <!-- 🌐 Top Navigation -->
    <?php include 'public/navbar.php'; ?>
    
    <!-- Main Content -->
    <main id="main-content">
        <!-- 🎥 Hero Video Section -->
        <?php include 'public/hero.php'; ?>
        
        <!-- 📢 Banner Event -->
        <?php include 'public/banner.php'; ?>
        
        <!-- 💎 Product Features -->
        <?php include 'public/product.php'; ?>
        
        <!-- 🏘️ Tipe Unit Rumah -->
        <?php include 'public/unit-types.php'; ?>
        
        <!-- 🖼️ Galeri Gambar -->
        <?php include 'public/gallery.php'; ?>
        
        <!-- 🎞️ Video Shorts -->
        <?php include 'public/video-short.php'; ?>
        
        <!-- 🏞️ Fasilitas -->
        <?php include 'public/facilities.php'; ?>
        
        <!-- 🗺️ Peta Lokasi -->
        <?php include 'public/map.php'; ?>
        
        <!-- 💬 Testimoni -->
        <?php include 'public/testimonials.php'; ?>
        
        <!-- 📲 Barcode WA -->
        <?php include 'public/barcode.php'; ?>
    </main>
    
    <!-- 🧱 Footer -->
    <?php include 'public/footer.php'; ?>
    
    <!-- 🟢 WhatsApp Floating Button -->
    <a href="https://wa.me/6282123862050?text=Halo,%20saya%20tertarik%20dengan%20Neo%20Green%20Terrace" 
       class="wa-float" 
       target="_blank" 
       rel="noopener noreferrer"
       aria-label="Chat WhatsApp">
        <img src="<?= asset_url('public/assets/icons/whatsapp.svg') ?>" alt="WhatsApp">
    </a>
    
    <!-- Back to Top Button -->
    <button id="back-to-top" class="back-to-top" aria-label="Back to top">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M12 19V5M5 12l7-7 7 7"/>
        </svg>
    </button>
    
    <!-- JavaScript Files -->
    <script src="<?= asset_url('public/assets/js/script.js') ?>" defer></script>
    <script src="<?= asset_url('public/assets/js/visitor-tracker.js') ?>" defer></script>
    <script src="<?= asset_url('public/assets/js/lazy-load.js') ?>" defer></script>
    
    <!-- PWA Service Worker -->
    <script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('<?= asset_url('service-worker.js') ?>')
                .then(reg => console.log('Service Worker registered'))
                .catch(err => console.log('Service Worker registration failed'));
        });
    }
    </script>
    
    <!-- Structured Data for SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "RealEstateAgent",
        "name": "Neo Green Terrace",
        "description": "Perumahan modern di Indramayu dengan fasilitas lengkap",
        "url": "<?= BASE_URL ?>",
        "logo": "<?= asset_url('uploads/logo/logo.png') ?>",
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+62-821-2386-2050",
            "contactType": "sales",
            "areaServed": "ID",
            "availableLanguage": ["Indonesian", "English"]
        },
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Indramayu",
            "addressRegion": "Jawa Barat",
            "addressCountry": "ID"
        }
    }
    </script>
</body>
</html>